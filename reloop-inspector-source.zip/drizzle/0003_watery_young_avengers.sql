CREATE TABLE `persistence_rate_limits` (
	`keyHash` varchar(64) NOT NULL,
	`windowStartedAtMs` bigint NOT NULL,
	`requestCount` int NOT NULL,
	`updatedAtMs` bigint NOT NULL,
	CONSTRAINT `persistence_rate_limits_keyHash` PRIMARY KEY(`keyHash`)
);
