CREATE TABLE `inspection_audit_events` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`timestampMs` bigint NOT NULL,
	`type` varchar(64) NOT NULL,
	`summary` text NOT NULL,
	`reasonCode` varchar(64),
	CONSTRAINT `inspection_audit_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inspection_captures` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`view` enum('front','left_oblique','right_oblique','back') NOT NULL,
	`capturedAtMs` bigint NOT NULL,
	`sourceName` varchar(255) NOT NULL,
	`sourceSha256` varchar(64) NOT NULL,
	`sourceWidth` int NOT NULL,
	`sourceHeight` int NOT NULL,
	`sourceObjectKey` varchar(512) NOT NULL,
	`sourceObjectUrl` text NOT NULL,
	`overlayObjectKey` varchar(512) NOT NULL,
	`overlayObjectUrl` text NOT NULL,
	`analysisJson` text NOT NULL,
	`accepted` boolean NOT NULL,
	CONSTRAINT `inspection_captures_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `inspection_sessions` (
	`id` varchar(64) NOT NULL,
	`accessTokenHash` varchar(64) NOT NULL,
	`deviceLabel` varchar(64) NOT NULL,
	`status` enum('setup','capturing','ready_for_review','reviewed') NOT NULL,
	`requestedView` enum('front','left_oblique','right_oblique','back') NOT NULL,
	`consentAccepted` boolean NOT NULL,
	`retentionExpiresAtMs` bigint NOT NULL,
	`acceptedViewsJson` text NOT NULL,
	`decisionHistoryJson` text NOT NULL,
	`reviewRecordJson` text,
	`createdAtMs` bigint NOT NULL,
	`updatedAtMs` bigint NOT NULL,
	CONSTRAINT `inspection_sessions_id` PRIMARY KEY(`id`)
);
