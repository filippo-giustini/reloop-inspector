import { bigint, boolean, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const inspectionSessions = mysqlTable("inspection_sessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  accessTokenHash: varchar("accessTokenHash", { length: 64 }).notNull(),
  deviceLabel: varchar("deviceLabel", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["setup", "capturing", "ready_for_review", "completed", "deferred"]).notNull(),
  requestedView: mysqlEnum("requestedView", ["front", "left_oblique", "right_oblique", "back"]).notNull(),
  consentAccepted: boolean("consentAccepted").notNull(),
  retentionExpiresAtMs: bigint("retentionExpiresAtMs", { mode: "number" }).notNull(),
  acceptedViewsJson: text("acceptedViewsJson").notNull(),
  decisionHistoryJson: text("decisionHistoryJson").notNull(),
  reviewRecordJson: text("reviewRecordJson"),
  createdAtMs: bigint("createdAtMs", { mode: "number" }).notNull(),
  updatedAtMs: bigint("updatedAtMs", { mode: "number" }).notNull(),
});

export const inspectionCaptures = mysqlTable("inspection_captures", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull(),
  view: mysqlEnum("view", ["front", "left_oblique", "right_oblique", "back"]).notNull(),
  capturedAtMs: bigint("capturedAtMs", { mode: "number" }).notNull(),
  sourceName: varchar("sourceName", { length: 255 }).notNull(),
  sourceSha256: varchar("sourceSha256", { length: 64 }).notNull(),
  sourceWidth: int("sourceWidth").notNull(),
  sourceHeight: int("sourceHeight").notNull(),
  sourceObjectKey: varchar("sourceObjectKey", { length: 512 }).notNull(),
  sourceObjectUrl: text("sourceObjectUrl").notNull(),
  overlayObjectKey: varchar("overlayObjectKey", { length: 512 }).notNull(),
  overlayObjectUrl: text("overlayObjectUrl").notNull(),
  analysisJson: text("analysisJson").notNull(),
  accepted: boolean("accepted").notNull(),
});

export const inspectionAuditEvents = mysqlTable("inspection_audit_events", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull(),
  timestampMs: bigint("timestampMs", { mode: "number" }).notNull(),
  type: varchar("type", { length: 64 }).notNull(),
  summary: text("summary").notNull(),
  reasonCode: varchar("reasonCode", { length: 64 }),
});

export const persistenceRateLimits = mysqlTable("persistence_rate_limits", {
  keyHash: varchar("keyHash", { length: 64 }).primaryKey(),
  windowStartedAtMs: bigint("windowStartedAtMs", { mode: "number" }).notNull(),
  requestCount: int("requestCount").notNull(),
  updatedAtMs: bigint("updatedAtMs", { mode: "number" }).notNull(),
});

export type InspectionSessionRow = typeof inspectionSessions.$inferSelect;
export type InsertInspectionSession = typeof inspectionSessions.$inferInsert;
export type InspectionCaptureRow = typeof inspectionCaptures.$inferSelect;
export type InsertInspectionCapture = typeof inspectionCaptures.$inferInsert;
export type InsertInspectionAuditEvent = typeof inspectionAuditEvents.$inferInsert;
