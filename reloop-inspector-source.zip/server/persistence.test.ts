import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { appRouter } from "./routers";
import { decodeEvidenceDataUrl, retentionExpiry } from "./persistenceRouter";

describe("synthetic evidence persistence guards", () => {
  it("decodes only the declared evidence MIME type", () => {
    const jpegBytes = Buffer.from([0xff, 0xd8, 0xff, 0x73, 0x79, 0x6e]);
    const jpeg = `data:image/jpeg;base64,${jpegBytes.toString("base64")}`;
    expect(decodeEvidenceDataUrl(jpeg, "image/jpeg")).toEqual(jpegBytes);
    expect(() => decodeEvidenceDataUrl(jpeg, "image/png")).toThrow("Expected image/png");
  });

  it("accepts the JPEG MIME emitted by the OpenCV evidence overlay", () => {
    const overlayBytes = Buffer.from([0xff, 0xd8, 0xff, 0x6f, 0x76, 0x65, 0x72, 0x6c, 0x61, 0x79]);
    const overlay = `data:image/jpeg;base64,${overlayBytes.toString("base64")}`;
    expect(decodeEvidenceDataUrl(overlay, "image/jpeg")).toEqual(overlayBytes);
  });

  it("uses a deterministic 24-hour synthetic-evidence retention boundary", () => {
    const createdAt = "2026-08-27T09:00:00.000Z";
    expect(retentionExpiry(createdAt)).toBe(Date.parse(createdAt) + 86_400_000);
  });

  it("rejects a source-hash mismatch and then enforces the durable limit through tRPC", async () => {
    const uniqueClient = `vitest-${crypto.randomUUID()}`;
    const ctx = {
      user: null,
      req: { headers: { "x-forwarded-for": uniqueClient }, ip: uniqueClient } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    } satisfies TrpcContext;
    const caller = appRouter.createCaller(ctx);
    const jpegBytes = Buffer.from([0xff, 0xd8, 0xff, 0x73, 0x79, 0x6e]);
    const dataUrl = `data:image/jpeg;base64,${jpegBytes.toString("base64")}`;
    const createdAt = new Date().toISOString();
    const input = {
      accessToken: crypto.randomUUID(),
      session: {
        id: crypto.randomUUID(),
        deviceLabel: "synthetic-reference-device" as const,
        createdAt,
        updatedAt: createdAt,
        consentAccepted: true as const,
        requestedView: "front" as const,
        status: "capturing" as const,
        acceptedViews: [],
        decisionHistory: [],
        auditEvents: [],
        review: null,
      },
      capture: {
        id: crypto.randomUUID(),
        view: "front" as const,
        capturedAt: createdAt,
        sourceName: "synthetic-front.jpg",
        sourceSha256: "0".repeat(64),
        sourceWidth: 100,
        sourceHeight: 100,
        sourceDataUrl: dataUrl,
        analysis: {
          captureId: crypto.randomUUID(),
          opencvVersion: "5.0.0",
          processingMs: 1,
          overlayDataUrl: dataUrl,
          metrics: [],
          decision: { status: "recapture" },
          proposal: { band: "manual-review" },
        } as any,
        accepted: false,
      },
    };

    for (let attempt = 0; attempt < 18; attempt += 1) {
      await expect(caller.persistence.saveSyntheticSnapshot(input)).rejects.toThrow("source hash does not match");
    }
    await expect(caller.persistence.saveSyntheticSnapshot(input)).rejects.toThrow("rate limit reached");
  });
});
