import { eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertInspectionAuditEvent,
  InsertInspectionCapture,
  InsertInspectionSession,
  InsertUser,
  inspectionAuditEvents,
  inspectionCaptures,
  inspectionSessions,
  persistenceRateLimits,
  users,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function assertInspectionAccess(sessionId: string, accessTokenHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db.select({ accessTokenHash: inspectionSessions.accessTokenHash })
    .from(inspectionSessions)
    .where(eq(inspectionSessions.id, sessionId))
    .limit(1);
  if (rows[0] && rows[0].accessTokenHash !== accessTokenHash) {
    throw new Error("Inspection access token does not match this session");
  }
}

export async function persistInspectionSnapshot(input: {
  session: InsertInspectionSession;
  capture?: InsertInspectionCapture;
  auditEvents: InsertInspectionAuditEvent[];
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  await db.insert(inspectionSessions).values(input.session).onDuplicateKeyUpdate({
    set: {
      deviceLabel: input.session.deviceLabel,
      status: input.session.status,
      requestedView: input.session.requestedView,
      consentAccepted: input.session.consentAccepted,
      retentionExpiresAtMs: input.session.retentionExpiresAtMs,
      acceptedViewsJson: input.session.acceptedViewsJson,
      decisionHistoryJson: input.session.decisionHistoryJson,
      reviewRecordJson: input.session.reviewRecordJson,
      updatedAtMs: input.session.updatedAtMs,
    },
  });

  if (input.capture) {
    await db.insert(inspectionCaptures).values(input.capture).onDuplicateKeyUpdate({
      set: {
        sourceObjectKey: input.capture.sourceObjectKey,
        sourceObjectUrl: input.capture.sourceObjectUrl,
        overlayObjectKey: input.capture.overlayObjectKey,
        overlayObjectUrl: input.capture.overlayObjectUrl,
        analysisJson: input.capture.analysisJson,
        accepted: input.capture.accepted,
      },
    });
  }

  for (const event of input.auditEvents) {
    await db.insert(inspectionAuditEvents).values(event).onDuplicateKeyUpdate({
      set: {
        timestampMs: event.timestampMs,
        type: event.type,
        summary: event.summary,
        reasonCode: event.reasonCode,
      },
    });
  }
}

export async function consumePersistenceRateLimit(input: {
  keyHash: string;
  nowMs: number;
  windowMs: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const resetBeforeMs = input.nowMs - input.windowMs;

  await db.execute(sql`
    INSERT INTO ${persistenceRateLimits}
      (${persistenceRateLimits.keyHash}, ${persistenceRateLimits.windowStartedAtMs}, ${persistenceRateLimits.requestCount}, ${persistenceRateLimits.updatedAtMs})
    VALUES (${input.keyHash}, ${input.nowMs}, 1, ${input.nowMs})
    ON DUPLICATE KEY UPDATE
      ${persistenceRateLimits.requestCount} = IF(${persistenceRateLimits.windowStartedAtMs} <= ${resetBeforeMs}, 1, ${persistenceRateLimits.requestCount} + 1),
      ${persistenceRateLimits.windowStartedAtMs} = IF(${persistenceRateLimits.windowStartedAtMs} <= ${resetBeforeMs}, ${input.nowMs}, ${persistenceRateLimits.windowStartedAtMs}),
      ${persistenceRateLimits.updatedAtMs} = ${input.nowMs}
  `);

  const rows = await db.select({ requestCount: persistenceRateLimits.requestCount })
    .from(persistenceRateLimits)
    .where(eq(persistenceRateLimits.keyHash, input.keyHash))
    .limit(1);
  if (!rows[0]) throw new Error("Unable to read persistence rate-limit state");
  return rows[0].requestCount;
}
