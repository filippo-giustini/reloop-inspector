import { createHash } from "node:crypto";
import { z } from "zod";
import type { VisionAnalysisResult } from "../shared/inspection";
import { publicProcedure, router } from "./_core/trpc";
import { assertInspectionAccess, consumePersistenceRateLimit, persistInspectionSnapshot } from "./db";
import { storagePut } from "./storage";

const viewSchema = z.enum(["front", "left_oblique", "right_oblique", "back"]);
const statusSchema = z.enum(["setup", "capturing", "ready_for_review", "completed", "deferred"]);
const auditEventSchema = z.object({
  id: z.string().min(1).max(64),
  timestamp: z.string().datetime(),
  type: z.enum(["capture_submitted", "analysis_completed", "view_accepted", "review_completed"]),
  summary: z.string().min(1).max(800),
  reasonCode: z.string().max(64).optional(),
});
const sessionSchema = z.object({
  id: z.string().uuid(),
  deviceLabel: z.literal("synthetic-reference-device"),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  consentAccepted: z.literal(true),
  requestedView: viewSchema,
  status: statusSchema,
  acceptedViews: z.array(z.unknown()).max(4),
  decisionHistory: z.array(z.unknown()).max(12),
  auditEvents: z.array(auditEventSchema).max(48),
  review: z.unknown().nullable(),
});
const analysisSchema = z.custom<VisionAnalysisResult>(value => {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<VisionAnalysisResult>;
  return typeof candidate.captureId === "string"
    && candidate.captureId.length > 0
    && candidate.captureId.length <= 64
    && typeof candidate.opencvVersion === "string"
    && candidate.opencvVersion.length > 0
    && candidate.opencvVersion.length <= 32
    && typeof candidate.processingMs === "number"
    && candidate.processingMs >= 0
    && typeof candidate.overlayDataUrl === "string"
    && candidate.overlayDataUrl.length <= 8_000_000
    && Array.isArray(candidate.metrics)
    && Boolean(candidate.decision)
    && Boolean(candidate.proposal);
}, "Invalid OpenCV analysis payload");
const captureSchema = z.object({
  id: z.string().min(1).max(64),
  view: viewSchema,
  capturedAt: z.string().datetime(),
  sourceName: z.string().regex(/^synthetic-(front|left_oblique|right_oblique|back)(-blurred)?\.jpg$/),
  sourceSha256: z.string().regex(/^[a-f0-9]{64}$/),
  sourceWidth: z.number().int().positive().max(4096),
  sourceHeight: z.number().int().positive().max(4096),
  sourceDataUrl: z.string().max(8_000_000),
  analysis: analysisSchema,
  accepted: z.boolean(),
});

const PERSISTENCE_WINDOW_MS = 60 * 60 * 1000;
const PERSISTENCE_MAX_REQUESTS = 18;

export function decodeEvidenceDataUrl(dataUrl: string, allowedMime: "image/jpeg" | "image/png") {
  const match = dataUrl.match(/^data:(image\/(?:jpeg|png));base64,([A-Za-z0-9+/=]+)$/);
  if (!match || match[1] !== allowedMime) throw new Error(`Expected ${allowedMime} data URL`);
  const buffer = Buffer.from(match[2], "base64");
  if (!buffer.length || buffer.length > 7 * 1024 * 1024) throw new Error("Persisted evidence must be between 1 byte and 7 MB");
  const validSignature = allowedMime === "image/jpeg"
    ? buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff
    : buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (!validSignature) throw new Error(`Invalid ${allowedMime} file signature`);
  return buffer;
}

export function retentionExpiry(createdAt: string) {
  const createdAtMs = Date.parse(createdAt);
  if (!Number.isFinite(createdAtMs)) throw new Error("Invalid session creation time");
  return createdAtMs + 24 * 60 * 60 * 1000;
}

function tokenHash(accessToken: string) {
  return createHash("sha256").update(accessToken).digest("hex");
}

export const persistenceRouter = router({
  saveSyntheticSnapshot: publicProcedure
    .input(z.object({
      accessToken: z.string().min(20).max(128),
      session: sessionSchema,
      capture: captureSchema.optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const forwardedFor = ctx.req.headers["x-forwarded-for"];
      const clientKey = Array.isArray(forwardedFor) ? forwardedFor[0] : forwardedFor?.split(",")[0]?.trim() || ctx.req.ip || "unknown";
      const rateCount = await consumePersistenceRateLimit({
        keyHash: tokenHash(`synthetic-persistence:${clientKey}`),
        nowMs: Date.now(),
        windowMs: PERSISTENCE_WINDOW_MS,
      });
      if (rateCount > PERSISTENCE_MAX_REQUESTS) {
        throw new Error("Synthetic persistence rate limit reached; try again later");
      }
      const accessTokenHash = tokenHash(input.accessToken);
      await assertInspectionAccess(input.session.id, accessTokenHash);

      let captureRow;
      if (input.capture) {
        const source = decodeEvidenceDataUrl(input.capture.sourceDataUrl, "image/jpeg");
        const overlay = decodeEvidenceDataUrl(input.capture.analysis.overlayDataUrl, "image/jpeg");
        const computedSourceSha256 = createHash("sha256").update(source).digest("hex");
        if (computedSourceSha256 !== input.capture.sourceSha256) {
          throw new Error("Persisted source hash does not match the submitted evidence");
        }
        const sourceStored = await storagePut(
          `reloop/synthetic/${input.session.id}/${input.capture.id}/source.jpg`,
          source,
          "image/jpeg",
        );
        const overlayStored = await storagePut(
          `reloop/synthetic/${input.session.id}/${input.capture.id}/overlay.jpg`,
          overlay,
          "image/jpeg",
        );
        const { overlayDataUrl: _overlayDataUrl, ...analysisWithoutInlineOverlay } = input.capture.analysis;
        captureRow = {
          id: input.capture.id,
          sessionId: input.session.id,
          view: input.capture.view,
          capturedAtMs: Date.parse(input.capture.capturedAt),
          sourceName: input.capture.sourceName,
          sourceSha256: input.capture.sourceSha256,
          sourceWidth: input.capture.sourceWidth,
          sourceHeight: input.capture.sourceHeight,
          sourceObjectKey: sourceStored.key,
          sourceObjectUrl: sourceStored.url,
          overlayObjectKey: overlayStored.key,
          overlayObjectUrl: overlayStored.url,
          analysisJson: JSON.stringify(analysisWithoutInlineOverlay),
          accepted: input.capture.accepted,
        };
      }

      const createdAtMs = Date.parse(input.session.createdAt);
      const updatedAtMs = Date.parse(input.session.updatedAt);
      const retentionExpiresAtMs = retentionExpiry(input.session.createdAt);
      await persistInspectionSnapshot({
        session: {
          id: input.session.id,
          accessTokenHash,
          deviceLabel: input.session.deviceLabel,
          status: input.session.status,
          requestedView: input.session.requestedView,
          consentAccepted: input.session.consentAccepted,
          retentionExpiresAtMs,
          acceptedViewsJson: JSON.stringify(input.session.acceptedViews),
          decisionHistoryJson: JSON.stringify(input.session.decisionHistory),
          reviewRecordJson: input.session.review ? JSON.stringify(input.session.review) : null,
          createdAtMs,
          updatedAtMs,
        },
        capture: captureRow,
        auditEvents: input.session.auditEvents.map(event => ({
          id: event.id,
          sessionId: input.session.id,
          timestampMs: Date.parse(event.timestamp),
          type: event.type,
          summary: event.summary,
          reasonCode: event.reasonCode ?? null,
        })),
      });

      return {
        persisted: true as const,
        mode: "synthetic-reference-only" as const,
        retentionExpiresAtMs,
        sourceObjectUrl: captureRow?.sourceObjectUrl,
        overlayObjectUrl: captureRow?.overlayObjectUrl,
      };
    }),
});
