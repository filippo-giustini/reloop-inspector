#!/usr/bin/env python3
"""Profile representative OpenCV worker requests in the managed Linux runtime."""

from __future__ import annotations

import json
import statistics
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = {
    "front": "phone_good.jpg",
    "left_oblique": "phone_left_oblique.jpg",
    "right_oblique": "phone_right_oblique.jpg",
    "back": "phone_back.jpg",
}


def resident_kb(pid: int) -> int:
    try:
        for line in Path(f"/proc/{pid}/status").read_text().splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1])
    except (FileNotFoundError, ProcessLookupError):
        pass
    return 0


def profile_once(image_path: Path, view: str, run: int) -> dict[str, float | int | str]:
    payload = json.dumps({
        "imagePath": str(image_path),
        "captureId": f"profile-{view}-{run}",
        "requestedView": view,
        "acceptedViews": [],
    }).encode()
    process = subprocess.Popen(
        [sys.executable, str(ROOT / "python" / "vision_worker.py")],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    result: dict[str, bytes] = {}

    def communicate() -> None:
        stdout, stderr = process.communicate(payload)
        result["stdout"] = stdout
        result["stderr"] = stderr

    started = time.perf_counter()
    thread = threading.Thread(target=communicate, daemon=True)
    thread.start()
    peak_rss_kb = 0
    while thread.is_alive():
        peak_rss_kb = max(peak_rss_kb, resident_kb(process.pid))
        time.sleep(0.005)
    thread.join()
    wall_seconds = time.perf_counter() - started
    if process.returncode != 0:
        raise RuntimeError(result.get("stderr", b"").decode(errors="replace"))
    output = json.loads(result["stdout"])
    return {
        "view": view,
        "run": run,
        "wall_seconds": round(wall_seconds, 4),
        "peak_rss_kb": peak_rss_kb,
        "worker_ms": int(output["processingMs"]),
        "response_bytes": len(result["stdout"]),
    }


def main() -> None:
    docs = ROOT / "docs"
    docs.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="reloop-profile-") as directory:
        fixture_dir = Path(directory)
        subprocess.run([sys.executable, str(ROOT / "python" / "make_test_captures.py"), str(fixture_dir)], check=True, stdout=subprocess.DEVNULL)
        rows = [
            profile_once(fixture_dir / filename, view, run)
            for view, filename in FIXTURES.items()
            for run in range(1, 4)
        ]

    header = ["view", "run", "wall_seconds", "peak_rss_kb", "worker_ms", "response_bytes"]
    lines = ["\t".join(header)] + ["\t".join(str(row[key]) for key in header) for row in rows]
    (docs / "runtime_profile.tsv").write_text("\n".join(lines) + "\n")

    summary = {
        "runs": len(rows),
        "fixtures": list(FIXTURES),
        "averageWallSeconds": round(statistics.mean(float(row["wall_seconds"]) for row in rows), 4),
        "maximumWallSeconds": max(float(row["wall_seconds"]) for row in rows),
        "averageWorkerMs": round(statistics.mean(int(row["worker_ms"]) for row in rows), 1),
        "maximumWorkerMs": max(int(row["worker_ms"]) for row in rows),
        "averagePeakRssMb": round(statistics.mean(int(row["peak_rss_kb"]) for row in rows) / 1024, 1),
        "maximumPeakRssMb": round(max(int(row["peak_rss_kb"]) for row in rows) / 1024, 1),
        "averageResponseKb": round(statistics.mean(int(row["response_bytes"]) for row in rows) / 1024, 1),
        "maximumResponseKb": round(max(int(row["response_bytes"]) for row in rows) / 1024, 1),
        "scope": "Single-request synthetic reference fixtures; not a concurrency or production-accuracy benchmark.",
    }
    (docs / "runtime_profile_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
