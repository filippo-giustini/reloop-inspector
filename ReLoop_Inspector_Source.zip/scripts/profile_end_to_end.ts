import { readFile } from "node:fs/promises";
import path from "node:path";
import { analyseCapture } from "../server/vision";

const [imagePath, requestedView = "front"] = process.argv.slice(2);
if (!imagePath) throw new Error("Usage: profile_end_to_end.ts <image-path> [view]");

const bytes = await readFile(imagePath);
const extension = path.extname(imagePath).toLowerCase();
const mimeType = extension === ".png" ? "image/png" : extension === ".webp" ? "image/webp" : "image/jpeg";
const started = performance.now();
const result = await analyseCapture({
  imageDataUrl: `data:${mimeType};base64,${bytes.toString("base64")}`,
  requestedView: requestedView as "front" | "left_oblique" | "right_oblique" | "back",
  acceptedViews: [],
});
const serialized = JSON.stringify(result);
process.stdout.write(JSON.stringify({
  wallMs: Math.round(performance.now() - started),
  workerMs: result.processingMs,
  responseBytes: Buffer.byteLength(serialized),
  decodedImage: result.image,
  decision: result.decision.reasonCode,
}));
