#!/usr/bin/env python3
"""Profile the full Node-to-Python path and combined process-tree RSS."""

from __future__ import annotations

import json
import statistics
import subprocess
import tempfile
import threading
import time
from pathlib import Path

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def resident_kb(pid: int) -> int:
    try:
        for line in Path(f"/proc/{pid}/status").read_text().splitlines():
            if line.startswith("VmRSS:"):
                return int(line.split()[1])
    except (FileNotFoundError, ProcessLookupError):
        pass
    return 0


def child_pids(pid: int) -> list[int]:
    try:
        text = Path(f"/proc/{pid}/task/{pid}/children").read_text().strip()
        return [int(value) for value in text.split()] if text else []
    except (FileNotFoundError, ProcessLookupError):
        return []


def process_tree_rss_kb(root_pid: int) -> int:
    pending = [root_pid]
    seen: set[int] = set()
    total = 0
    while pending:
        pid = pending.pop()
        if pid in seen:
            continue
        seen.add(pid)
        total += resident_kb(pid)
        pending.extend(child_pids(pid))
    return total


def make_near_limit_image(path: Path) -> tuple[int, int]:
    width, height = 4096, 2929  # 11,997,184 pixels: below the 12 MP guard.
    image = np.full((height, width, 3), (226, 222, 211), dtype=np.uint8)
    polygon = np.array([[1320, 220], [2800, 220], [2920, 2700], [1200, 2700]], dtype=np.int32)
    cv2.fillConvexPoly(image, polygon, (39, 48, 43))
    cv2.polylines(image, [polygon], True, (235, 205, 51), 16, cv2.LINE_AA)
    for offset in range(0, 1180, 90):
        cv2.line(image, (1450, 520 + offset), (2700, 555 + offset), (96, 111, 101), 6, cv2.LINE_AA)
    cv2.circle(image, (2060, 350), 24, (196, 200, 190), -1, cv2.LINE_AA)
    if not cv2.imwrite(str(path), image, [int(cv2.IMWRITE_JPEG_QUALITY), 90]):
        raise RuntimeError("Unable to write near-limit fixture")
    return width, height


def profile_once(image_path: Path, run: int) -> dict[str, float | int | str | dict[str, int]]:
    process = subprocess.Popen(
        [str(ROOT / "node_modules" / ".bin" / "tsx"), str(ROOT / "scripts" / "profile_end_to_end.ts"), str(image_path), "front"],
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    output: dict[str, bytes] = {}

    def communicate() -> None:
        stdout, stderr = process.communicate()
        output["stdout"] = stdout
        output["stderr"] = stderr

    started = time.perf_counter()
    thread = threading.Thread(target=communicate, daemon=True)
    thread.start()
    peak_tree_rss_kb = 0
    while thread.is_alive():
        peak_tree_rss_kb = max(peak_tree_rss_kb, process_tree_rss_kb(process.pid))
        time.sleep(0.005)
    thread.join()
    wall_seconds = time.perf_counter() - started
    if process.returncode != 0:
        raise RuntimeError(output.get("stderr", b"").decode(errors="replace"))
    result = json.loads(output["stdout"])
    return {
        "run": run,
        "wall_seconds": round(wall_seconds, 4),
        "peak_process_tree_rss_kb": peak_tree_rss_kb,
        "application_wall_ms": int(result["wallMs"]),
        "worker_ms": int(result["workerMs"]),
        "response_bytes": int(result["responseBytes"]),
        "decoded_width": int(result["decodedImage"]["width"]),
        "decoded_height": int(result["decodedImage"]["height"]),
        "decision": str(result["decision"]),
    }


def main() -> None:
    docs = ROOT / "docs"
    docs.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="reloop-managed-profile-") as directory:
        image_path = Path(directory) / "near-limit-12mp.jpg"
        source_width, source_height = make_near_limit_image(image_path)
        source_bytes = image_path.stat().st_size
        rows = [profile_once(image_path, run) for run in range(1, 4)]

    header = ["run", "wall_seconds", "peak_process_tree_rss_kb", "application_wall_ms", "worker_ms", "response_bytes", "decoded_width", "decoded_height", "decision"]
    lines = ["\t".join(header)] + ["\t".join(str(row[key]) for key in header) for row in rows]
    (docs / "managed_path_profile.tsv").write_text("\n".join(lines) + "\n")

    summary = {
        "runs": len(rows),
        "sourceWidth": source_width,
        "sourceHeight": source_height,
        "sourcePixels": source_width * source_height,
        "sourceBytes": source_bytes,
        "decodedWorkerWidth": rows[0]["decoded_width"],
        "decodedWorkerHeight": rows[0]["decoded_height"],
        "averageEndToEndWallSeconds": round(statistics.mean(float(row["wall_seconds"]) for row in rows), 4),
        "maximumEndToEndWallSeconds": max(float(row["wall_seconds"]) for row in rows),
        "averageApplicationWallMs": round(statistics.mean(int(row["application_wall_ms"]) for row in rows), 1),
        "maximumApplicationWallMs": max(int(row["application_wall_ms"]) for row in rows),
        "maximumWorkerMs": max(int(row["worker_ms"]) for row in rows),
        "maximumCombinedProcessTreeRssMb": round(max(int(row["peak_process_tree_rss_kb"]) for row in rows) / 1024, 1),
        "maximumResponseKb": round(max(int(row["response_bytes"]) for row in rows) / 1024, 1),
        "memoryLimitMb": 512,
        "workerTimeoutSeconds": 15,
        "scope": "Full analyseCapture path in an isolated Node process plus descendant Python worker; three near-limit synthetic requests, not a concurrency benchmark.",
    }
    (docs / "managed_path_profile_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
