# Public Repository Sync

The public repository is available at <https://github.com/filippo-giustini/reloop-inspector>.

Commit `880872fdc9ad58e12e363857f7f336fc9912fc87` publishes the audited runnable source bundle, technical report, evaluation protocol, judge testing instructions, validation report, runtime profiles and MIT licence. Commit `8c2aa831d8c588f8df8dc755ee2adb8834b1529b` corrects the public README so every judge-facing link resolves against the flat browser-upload structure.

Because the authenticated GitHub CLI token was unavailable, the browser upload preserves the complete runnable tree inside `ReLoop_Inspector_Source.zip` and exposes the principal judge-facing documents at repository root. The source ZIP passed a local secret scan and archive-integrity check before upload. Public verification confirmed four commits and working links to the source archive, testing instructions, technical report, evaluation protocol, validation report and raw runtime profiles.
