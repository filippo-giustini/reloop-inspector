# Final Submission Checklist

| Item | Status | Action |
|---|---|---|
| Functioning OpenCV 5 prototype | Ready | Run the reference path once after publishing |
| Guided multi-view capture | Ready | Test one manual image flow on mobile |
| Corrective Agentic Vision loop | Ready | Show `FOCUS_TOO_LOW` and verified correction in video |
| Human-in-the-loop review | Ready | Demonstrate confirm and mention correct/defer |
| Evidence ZIP | Ready | Download and open before final submission |
| Tests and runtime profile | Ready | Preserve files under `docs/` |
| Public repository | Pending sync | Push this runnable code to GitHub |
| Public endpoint | Pending publish | Create checkpoint, then use the UI Publish button |
| Final video | Pending recording | Record the published prototype using `final_video_script.md` |
| Devpost copy | Ready after URL replacement | Replace the working-endpoint placeholder |
| AWS claim | Not active | Do not select or claim active AWS until real integration exists |
| Real-device accuracy | Not established | Keep limitations visible; do not claim precision/recall |
