import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import type { ExplainableMetric, PreviousCaptureSummary } from "../shared/inspection";
import { analyseCapture, getVisionHealth } from "./vision";

const fixtureDir = mkdtempSync(path.join(tmpdir(), "reloop-fixtures-"));

function imageDataUrl(filename: string) {
  const bytes = readFileSync(path.join(fixtureDir, filename));
  return `data:image/jpeg;base64,${bytes.toString("base64")}`;
}

function metricValue(metrics: ExplainableMetric[], id: ExplainableMetric["id"]) {
  return metrics.find(metric => metric.id === id)?.value ?? 0;
}

function oversizedPngHeaderDataUrl() {
  const bytes = Buffer.alloc(33);
  Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).copy(bytes, 0);
  bytes.writeUInt32BE(13, 8);
  bytes.write("IHDR", 12, "ascii");
  bytes.writeUInt32BE(10_000, 16);
  bytes.writeUInt32BE(10_000, 20);
  bytes[24] = 8;
  bytes[25] = 2;
  return `data:image/png;base64,${bytes.toString("base64")}`;
}

beforeAll(() => {
  execFileSync("python3", [path.resolve(process.cwd(), "python", "make_test_captures.py"), fixtureDir]);
});

afterAll(() => {
  rmSync(fixtureDir, { recursive: true, force: true });
});

describe("OpenCV 5 vision worker", () => {
  it("reports the real runtime version", async () => {
    const health = await getVisionHealth();
    expect(health.ok).toBe(true);
    expect(health.opencvVersion.startsWith("5.")).toBe(true);
  });

  it("rejects unsupported image payloads before spawning the worker", async () => {
    await expect(
      analyseCapture({
        imageDataUrl: "data:text/plain;base64,SGVsbG8=",
        requestedView: "front",
        acceptedViews: [],
      }),
    ).rejects.toThrow("Only JPEG, PNG, and WebP images are supported");
  });

  it("rejects compressed images whose decoded dimensions exceed the memory budget", async () => {
    await expect(
      analyseCapture({ imageDataUrl: oversizedPngHeaderDataUrl(), requestedView: "front", acceptedViews: [] }),
    ).rejects.toThrow("12-megapixel");
  });

  it("uses an OpenCV failure to request and verify a corrective capture", async () => {
    const rejected = await analyseCapture({
      imageDataUrl: imageDataUrl("phone_blurred.jpg"),
      requestedView: "front",
      acceptedViews: [],
    });

    expect(rejected.opencvVersion.startsWith("5.")).toBe(true);
    expect(rejected.decision.status).toBe("recapture");
    expect(rejected.decision.reasonCode).toBe("FOCUS_TOO_LOW");
    expect(rejected.overlayDataUrl.startsWith("data:image/jpeg;base64,")).toBe(true);

    const previousCapture: PreviousCaptureSummary = {
      reasonCode: rejected.decision.reasonCode,
      requestedView: "front",
      focus: metricValue(rejected.metrics, "focus"),
      luminance: metricValue(rejected.metrics, "luminance"),
      glare: metricValue(rejected.metrics, "glare"),
      coverage: metricValue(rejected.metrics, "coverage"),
      pose: metricValue(rejected.metrics, "pose"),
    };

    const corrected = await analyseCapture({
      imageDataUrl: imageDataUrl("phone_good.jpg"),
      requestedView: "front",
      acceptedViews: [],
      previousCapture,
    });

    expect(corrected.decision.verification.attempted).toBe(true);
    expect(corrected.decision.verification.passed).toBe(true);
    expect(corrected.decision.status).toBe("accepted");
    expect(corrected.decision.reasonCode).toBe("VIEW_ACCEPTED");
    expect(corrected.acceptedView?.view).toBe("front");
    expect(corrected.metrics).toHaveLength(7);
  });

  it("completes a four-view evidence set only after every requested pose passes", async () => {
    const acceptedViews = [];
    const sequence = [
      ["front", "phone_good.jpg"],
      ["left_oblique", "phone_left_oblique.jpg"],
      ["right_oblique", "phone_right_oblique.jpg"],
      ["back", "phone_back.jpg"],
    ] as const;

    for (const [index, [view, filename]] of sequence.entries()) {
      const result = await analyseCapture({
        imageDataUrl: imageDataUrl(filename),
        requestedView: view,
        acceptedViews,
      });
      expect(result.decision.status).toBe(index === sequence.length - 1 ? "complete" : "accepted");
      expect(result.acceptedView?.view).toBe(view);
      if (result.acceptedView) acceptedViews.push(result.acceptedView);
    }

    expect(acceptedViews.map(item => item.view)).toEqual(["front", "left_oblique", "right_oblique", "back"]);
  });
});
