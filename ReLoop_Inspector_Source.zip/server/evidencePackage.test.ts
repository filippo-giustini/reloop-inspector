import type { InspectionSession } from "@shared/inspection";
import { describe, expect, it } from "vitest";
import { unzipSync } from "fflate";
import { buildEvidenceFiles, evidenceZip, privacySafeAudit } from "../client/src/lib/evidencePackage";

const tinyJpeg = "data:image/jpeg;base64,/9j/2Q==";
const session = {
  id: "session-test",
  deviceLabel: "synthetic-reference-device",
  createdAt: "2026-08-27T00:00:00.000Z",
  updatedAt: "2026-08-27T00:01:00.000Z",
  consentAccepted: true,
  requestedView: "front",
  acceptedViews: [],
  decisionHistory: [],
  auditEvents: [],
  review: { action: "confirmed", finalBand: "manual-review", note: "", reviewedAt: "2026-08-27T00:01:00.000Z" },
  status: "completed",
  captures: [{
    id: "capture-front",
    view: "front",
    capturedAt: "2026-08-27T00:00:30.000Z",
    sourceName: "front.jpg",
    sourceSha256: "abc123",
    sourceWidth: 1280,
    sourceHeight: 900,
    sourceDataUrl: tinyJpeg,
    accepted: true,
    analysis: {
      captureId: "capture-front",
      opencvVersion: "5.0.0",
      processingMs: 42,
      requestedView: "front",
      overlayDataUrl: tinyJpeg,
      metrics: [],
      defects: [],
      decision: { status: "accepted", reasonCode: "VIEW_ACCEPTED", instruction: "Continue", explanation: "All gates passed.", nextView: "left_oblique", verification: { attempted: false, passed: false, explanation: "Not required." } },
      acceptedView: null,
      proposal: null,
    },
  }],
} satisfies InspectionSession;

describe("privacy-safe evidence package", () => {
  it("removes source data URLs and references rendered overlays", () => {
    const audit = privacySafeAudit(session);
    expect("sourceDataUrl" in audit.captures[0]).toBe(false);
    expect(audit.captures[0].analysis.overlayDataUrl).toBe("evidence/01-front-glass-overlay.jpg");
  });

  it("creates a readable ZIP with audit, manifest and evidence overlay", () => {
    const files = buildEvidenceFiles(session);
    expect(Object.keys(files)).toContain("evidence/01-front-glass-overlay.jpg");
    const archive = unzipSync(evidenceZip(session));
    expect(Object.keys(archive)).toEqual(expect.arrayContaining(["README.txt", "audit.json", "evidence/manifest.json", "evidence/01-front-glass-overlay.jpg"]));
  });
});
