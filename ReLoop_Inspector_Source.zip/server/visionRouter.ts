import { z } from "zod";
import { CAPTURE_VIEWS, REASON_CODES } from "../shared/inspection";
import { publicProcedure, router } from "./_core/trpc";
import { analyseCapture, getVisionHealth } from "./vision";

const viewSchema = z.enum(CAPTURE_VIEWS);
const reasonSchema = z.enum(REASON_CODES);

const acceptedViewSchema = z.object({
  view: viewSchema,
  captureId: z.string().uuid(),
  focus: z.number().finite(),
  glare: z.number().finite(),
  coverage: z.number().finite(),
  candidateMarks: z.number().int().nonnegative(),
});

const previousCaptureSchema = z.object({
  reasonCode: reasonSchema,
  requestedView: viewSchema,
  focus: z.number().finite(),
  luminance: z.number().finite(),
  glare: z.number().finite(),
  coverage: z.number().finite(),
  pose: z.number().finite(),
});

export const visionRouter = router({
  health: publicProcedure.query(() => getVisionHealth()),
  analyse: publicProcedure
    .input(
      z.object({
        imageDataUrl: z.string().min(100).max(12_000_000),
        requestedView: viewSchema,
        acceptedViews: z.array(acceptedViewSchema).max(4),
        previousCapture: previousCaptureSchema.optional(),
      }),
    )
    .mutation(({ input }) => analyseCapture(input)),
});

