import { randomUUID } from "node:crypto";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { imageSize } from "image-size";
import type {
  AcceptedViewSummary,
  CaptureView,
  PreviousCaptureSummary,
  VisionAnalysisResult,
} from "../shared/inspection";

const MAX_IMAGE_BYTES = 7 * 1024 * 1024;
const MAX_IMAGE_PIXELS = 12_000_000;
const MAX_IMAGE_SIDE = 4_096;
const MAX_WORKER_OUTPUT_CHARS = 8_000_000;
const WORKER_TIMEOUT_MS = 15_000;
const ALLOWED_MIME_TYPES = new Set(["image/jpeg", "image/png", "image/webp"]);

type VisionInput = {
  imageDataUrl: string;
  requestedView: CaptureView;
  acceptedViews: AcceptedViewSummary[];
  previousCapture?: PreviousCaptureSummary;
};

type WorkerPayload = Omit<VisionInput, "imageDataUrl"> & {
  imagePath: string;
  captureId: string;
};

function decodeImageDataUrl(dataUrl: string) {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=\s]+)$/.exec(dataUrl);
  if (!match || !ALLOWED_MIME_TYPES.has(match[1])) {
    throw new Error("Only JPEG, PNG, and WebP images are supported");
  }
  const buffer = Buffer.from(match[2].replace(/\s/g, ""), "base64");
  if (!buffer.length || buffer.length > MAX_IMAGE_BYTES) {
    throw new Error("Image must be non-empty and no larger than 7 MB after browser compression");
  }
  const dimensions = imageSize(buffer);
  if (!dimensions.width || !dimensions.height) throw new Error("Unable to read image dimensions");
  if (dimensions.width > MAX_IMAGE_SIDE || dimensions.height > MAX_IMAGE_SIDE || dimensions.width * dimensions.height > MAX_IMAGE_PIXELS) {
    throw new Error("Decoded image dimensions exceed the 12-megapixel / 4096-pixel safety limit");
  }
  return { buffer, mimeType: match[1] };
}

function workerPath() {
  return path.resolve(process.cwd(), "python", "vision_worker.py");
}

function runWorker(payload: WorkerPayload): Promise<VisionAnalysisResult> {
  return new Promise((resolve, reject) => {
    const child = spawn("python3", [workerPath()], {
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, PYTHONUNBUFFERED: "1" },
    });
    let stdout = "";
    let stderr = "";
    const timeout = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("OpenCV analysis exceeded the 15-second safety limit"));
    }, WORKER_TIMEOUT_MS);
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", chunk => {
      stdout += chunk;
      if (stdout.length > MAX_WORKER_OUTPUT_CHARS) {
        child.kill("SIGKILL");
        reject(new Error("OpenCV worker output exceeded the response safety limit"));
      }
    });
    child.stderr.on("data", chunk => {
      stderr = (stderr + chunk).slice(-65_536);
    });
    child.on("error", error => {
      clearTimeout(timeout);
      reject(error);
    });
    child.on("close", code => {
      clearTimeout(timeout);
      if (code !== 0) {
        reject(new Error(stderr.trim() || `OpenCV worker exited with code ${code}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout) as VisionAnalysisResult);
      } catch {
        reject(new Error("OpenCV worker returned invalid JSON"));
      }
    });
    child.stdin.end(JSON.stringify(payload));
  });
}

export async function analyseCapture(input: VisionInput): Promise<VisionAnalysisResult> {
  const { buffer, mimeType } = decodeImageDataUrl(input.imageDataUrl);
  const captureId = randomUUID();
  const directory = await mkdtemp(path.join(tmpdir(), "reloop-"));
  const extension = mimeType === "image/png" ? "png" : mimeType === "image/webp" ? "webp" : "jpg";
  const imagePath = path.join(directory, `capture.${extension}`);
  try {
    await writeFile(imagePath, buffer);
    return await runWorker({
      imagePath,
      captureId,
      requestedView: input.requestedView,
      acceptedViews: input.acceptedViews,
      previousCapture: input.previousCapture,
    });
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}

export function getVisionHealth(): Promise<{ ok: boolean; opencvVersion: string; numpyVersion: string }> {
  return new Promise((resolve, reject) => {
    const child = spawn("python3", [workerPath(), "--health"], { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    const timeout = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("OpenCV health check timed out"));
    }, 10_000);
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", chunk => (stdout += chunk));
    child.stderr.on("data", chunk => (stderr += chunk));
    child.on("error", error => {
      clearTimeout(timeout);
      reject(error);
    });
    child.on("close", code => {
      clearTimeout(timeout);
      if (code !== 0) return reject(new Error(stderr.trim() || "OpenCV health check failed"));
      resolve(JSON.parse(stdout));
    });
  });
}
