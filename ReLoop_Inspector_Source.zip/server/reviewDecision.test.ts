import type { InspectionSession } from "../shared/inspection";
import { describe, expect, it } from "vitest";
import { applyReviewDecision, reviewValidationError } from "../client/src/lib/reviewDecision";

const baseSession = {
  id: "session-review-test",
  deviceLabel: "synthetic-reference-device",
  createdAt: "2026-08-27T00:00:00.000Z",
  updatedAt: "2026-08-27T00:00:00.000Z",
  consentAccepted: true,
  requestedView: "back",
  acceptedViews: [],
  decisionHistory: [],
  auditEvents: [],
  review: null,
  status: "review",
  captures: [],
} satisfies InspectionSession;

describe("human review decisions", () => {
  it("confirms the proposed band and appends an audit event", () => {
    const result = applyReviewDecision({ session: baseSession, action: "confirmed", proposedBand: "B-candidate", overrideBand: "manual-review", note: "", reviewedAt: "2026-08-27T00:01:00.000Z", eventId: "event-1" });
    expect(result.status).toBe("completed");
    expect(result.review?.finalBand).toBe("B-candidate");
    expect(result.auditEvents.at(-1)?.type).toBe("review_completed");
  });

  it("requires rationale for correction and deferral", () => {
    expect(reviewValidationError("corrected", " ")).toContain("corrected");
    expect(reviewValidationError("deferred", "")).toContain("deferred");
  });

  it("records a motivated correction without altering the evidence set", () => {
    const result = applyReviewDecision({ session: baseSession, action: "corrected", proposedBand: "B-candidate", overrideBand: "manual-review", note: "Visible ambiguity requires manual inspection.", reviewedAt: "2026-08-27T00:02:00.000Z", eventId: "event-2" });
    expect(result.review).toMatchObject({ action: "corrected", finalBand: "manual-review", note: "Visible ambiguity requires manual inspection." });
    expect(result.acceptedViews).toEqual(baseSession.acceptedViews);
  });
});
