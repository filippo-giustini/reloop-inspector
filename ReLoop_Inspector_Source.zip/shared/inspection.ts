export const CAPTURE_VIEWS = [
  "front",
  "left_oblique",
  "right_oblique",
  "back",
] as const;

export type CaptureView = (typeof CAPTURE_VIEWS)[number];

export const REASON_CODES = [
  "IMAGE_TOO_SMALL",
  "FOCUS_TOO_LOW",
  "UNDEREXPOSED",
  "OVEREXPOSED",
  "EXCESSIVE_GLARE",
  "DEVICE_NOT_FOUND",
  "DEVICE_TOO_SMALL",
  "POSE_NOT_VERIFIED",
  "CORRECTIVE_ACTION_NOT_VERIFIED",
  "VIEW_ACCEPTED",
  "EVIDENCE_SET_COMPLETE",
] as const;

export type ReasonCode = (typeof REASON_CODES)[number];

export type MetricStatus = "pass" | "warn" | "fail";

export interface ExplainableMetric {
  id: "focus" | "luminance" | "blackClipping" | "whiteClipping" | "glare" | "coverage" | "pose";
  label: string;
  value: number;
  unit: string;
  threshold: string;
  status: MetricStatus;
  explanation: string;
}

export interface VisionEvidence {
  type: "device_boundary" | "glare_region" | "candidate_surface_mark" | "pose_axis";
  label: string;
  confidence: number;
}

export interface AgentVerification {
  attempted: boolean;
  passed: boolean;
  metricId?: ExplainableMetric["id"];
  previousValue?: number;
  currentValue?: number;
  requiredChange?: string;
  explanation: string;
}

export interface AgentDecision {
  status: "recapture" | "accepted" | "complete";
  reasonCode: ReasonCode;
  requestedView: CaptureView;
  nextView: CaptureView | null;
  instruction: string;
  explanation: string;
  verification: AgentVerification;
}

export interface CosmeticProposal {
  band: "A-candidate" | "B-candidate" | "C-candidate" | "manual-review";
  confidence: number;
  rationale: string[];
  disclaimer: string;
}

export interface AcceptedViewSummary {
  view: CaptureView;
  captureId: string;
  focus: number;
  glare: number;
  coverage: number;
  candidateMarks: number;
}

export interface PreviousCaptureSummary {
  reasonCode: ReasonCode;
  requestedView: CaptureView;
  focus: number;
  luminance: number;
  glare: number;
  coverage: number;
  pose: number;
}

export interface VisionAnalysisResult {
  captureId: string;
  opencvVersion: string;
  processingMs: number;
  image: { width: number; height: number };
  metrics: ExplainableMetric[];
  evidence: VisionEvidence[];
  decision: AgentDecision;
  proposal: CosmeticProposal;
  acceptedView?: AcceptedViewSummary;
  overlayDataUrl: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  type: "capture_submitted" | "analysis_completed" | "view_accepted" | "review_completed";
  summary: string;
  reasonCode?: ReasonCode;
}

export interface HumanReview {
  action: "confirmed" | "corrected" | "deferred";
  finalBand: CosmeticProposal["band"];
  note: string;
  reviewedAt: string;
}

export interface CaptureRecord {
  id: string;
  view: CaptureView;
  capturedAt: string;
  sourceName: string;
  sourceSha256: string;
  sourceWidth: number;
  sourceHeight: number;
  sourceDataUrl: string;
  analysis: VisionAnalysisResult;
  accepted: boolean;
}

export interface InspectionSession {
  id: string;
  deviceLabel: string;
  createdAt: string;
  updatedAt: string;
  consentAccepted: boolean;
  requestedView: CaptureView;
  captures: CaptureRecord[];
  acceptedViews: AcceptedViewSummary[];
  decisionHistory: AgentDecision[];
  auditEvents: AuditEvent[];
  review: HumanReview | null;
  status: "setup" | "capturing" | "ready_for_review" | "completed" | "deferred";
}
