import type { CosmeticProposal, InspectionSession } from "@shared/inspection";

export type ReviewAction = "confirmed" | "corrected" | "deferred";

export function reviewValidationError(action: ReviewAction, note: string) {
  if (action === "corrected" && !note.trim()) return "Explain why the proposal was corrected.";
  if (action === "deferred" && !note.trim()) return "Record why the decision was deferred.";
  return null;
}

export function applyReviewDecision(input: {
  session: InspectionSession;
  action: ReviewAction;
  proposedBand: CosmeticProposal["band"];
  overrideBand: CosmeticProposal["band"];
  note: string;
  reviewedAt: string;
  eventId: string;
}) {
  const { session, action, proposedBand, overrideBand, reviewedAt, eventId } = input;
  const note = input.note.trim();
  const error = reviewValidationError(action, note);
  if (error) throw new Error(error);
  const finalBand = action === "confirmed" ? proposedBand : action === "corrected" ? overrideBand : "manual-review";

  return {
    ...session,
    review: { action, finalBand, note, reviewedAt },
    status: action === "deferred" ? "deferred" as const : "completed" as const,
    updatedAt: reviewedAt,
    auditEvents: [...session.auditEvents, { id: eventId, timestamp: reviewedAt, type: "review_completed" as const, summary: `Human review: ${action}; final band ${finalBand}.` }],
  } satisfies InspectionSession;
}
