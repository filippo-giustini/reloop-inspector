import type { CaptureView, InspectionSession } from "@shared/inspection";
import { strToU8, zipSync } from "fflate";

const VIEW_FILE_NAMES: Record<CaptureView, string> = {
  front: "01-front-glass-overlay.jpg",
  left_oblique: "02-left-oblique-overlay.jpg",
  right_oblique: "03-right-oblique-overlay.jpg",
  back: "04-back-housing-overlay.jpg",
};

export function privacySafeAudit(session: InspectionSession) {
  return {
    ...session,
    captures: session.captures.map(({ sourceDataUrl: _source, analysis, ...capture }) => ({
      ...capture,
      rawImagePersisted: false,
      analysis: { ...analysis, overlayDataUrl: `evidence/${VIEW_FILE_NAMES[capture.view]}` },
    })),
    exportNotice: "Source photographs are not packaged as separate files. Accepted-view OpenCV overlays are included in the evidence directory; verify provenance using SHA-256 hashes and timestamps.",
  };
}

function dataUrlBytes(dataUrl: string) {
  const encoded = dataUrl.split(",")[1];
  if (!encoded) throw new Error("Evidence overlay data is unavailable.");
  return Uint8Array.from(atob(encoded), character => character.charCodeAt(0));
}

export function buildEvidenceFiles(session: InspectionSession) {
  const audit = privacySafeAudit(session);
  const acceptedCaptures = (Object.keys(VIEW_FILE_NAMES) as CaptureView[])
    .map(view => [...session.captures].reverse().find(capture => capture.view === view && capture.accepted))
    .filter((capture): capture is NonNullable<typeof capture> => Boolean(capture));

  const manifest = acceptedCaptures.map(capture => ({
    view: capture.view,
    captureId: capture.id,
    capturedAt: capture.capturedAt,
    sourceSha256: capture.sourceSha256,
    overlayFile: `evidence/${VIEW_FILE_NAMES[capture.view]}`,
    reasonCode: capture.analysis.decision.reasonCode,
    opencvVersion: capture.analysis.opencvVersion,
    processingMs: capture.analysis.processingMs,
    metrics: capture.analysis.metrics,
  }));

  const files: Record<string, Uint8Array> = {
    "README.txt": strToU8([
      "ReLoop Inspector — privacy-safe evidence package",
      "",
      "This package was exported by the public prototype after human review.",
      "It contains the audit record, per-view provenance and rendered OpenCV evidence overlays.",
      "Original source photographs are not included as separate files.",
      "Candidate surface marks and cosmetic bands are prototype heuristics, not validated defects or safety certifications.",
    ].join("\n")),
    "audit.json": strToU8(JSON.stringify(audit, null, 2)),
    "evidence/manifest.json": strToU8(JSON.stringify(manifest, null, 2)),
  };

  acceptedCaptures.forEach(capture => {
    files[`evidence/${VIEW_FILE_NAMES[capture.view]}`] = dataUrlBytes(capture.analysis.overlayDataUrl);
  });
  return files;
}

export function evidenceZip(session: InspectionSession) {
  return zipSync(buildEvidenceFiles(session), { level: 6 });
}
