import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { evidenceZip, privacySafeAudit } from "@/lib/evidencePackage";
import { applyReviewDecision, reviewValidationError } from "@/lib/reviewDecision";
import type {
  AcceptedViewSummary,
  CaptureRecord,
  CaptureView,
  CosmeticProposal,
  ExplainableMetric,
  InspectionSession,
  PreviousCaptureSummary,
} from "@shared/inspection";
import {
  Aperture,
  ArrowRight,
  Camera,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  CircleGauge,
  Download,
  Eye,
  FileCheck2,
  Fingerprint,
  ImagePlus,
  LoaderCircle,
  RefreshCw,
  RotateCcw,
  ScanLine,
  ShieldCheck,
  Sparkles,
  UserCheck,
  X,
} from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const VIEW_LABELS: Record<CaptureView, string> = {
  front: "Front glass",
  left_oblique: "Left oblique",
  right_oblique: "Right oblique",
  back: "Back housing",
};

const VIEW_NOTES: Record<CaptureView, string> = {
  front: "Keep the phone parallel to the camera. Show all four corners and avoid direct flash.",
  left_oblique: "Tilt the left edge away by roughly 15–25°. Keep the full device visible.",
  right_oblique: "Tilt the right edge away by roughly 15–25°. Keep the full device visible.",
  back: "Turn the phone over and capture the complete housing, including camera surround and corners.",
};

function nowIso() {
  return new Date().toISOString();
}

function newSession(): InspectionSession {
  const timestamp = nowIso();
  return {
    id: crypto.randomUUID(),
    deviceLabel: "",
    createdAt: timestamp,
    updatedAt: timestamp,
    consentAccepted: false,
    requestedView: "front",
    captures: [],
    acceptedViews: [],
    decisionHistory: [],
    auditEvents: [],
    review: null,
    status: "setup",
  };
}

function findMetric(metrics: ExplainableMetric[], id: ExplainableMetric["id"]) {
  return metrics.find(metric => metric.id === id)?.value ?? 0;
}

function previousSummary(capture?: CaptureRecord): PreviousCaptureSummary | undefined {
  if (!capture || capture.analysis.decision.status !== "recapture") return undefined;
  const metrics = capture.analysis.metrics;
  return {
    reasonCode: capture.analysis.decision.reasonCode,
    requestedView: capture.view,
    focus: findMetric(metrics, "focus"),
    luminance: findMetric(metrics, "luminance"),
    glare: findMetric(metrics, "glare"),
    coverage: findMetric(metrics, "coverage"),
    pose: findMetric(metrics, "pose"),
  };
}

async function fileToCapture(file: File) {
  if (!file.type.startsWith("image/")) throw new Error("Choose a JPEG, PNG, or WebP image.");
  if (file.size > 14 * 1024 * 1024) throw new Error("The original image must be smaller than 14 MB.");

  const sourceUrl = URL.createObjectURL(file);
  const image = new Image();
  await new Promise<void>((resolve, reject) => {
    image.onload = () => resolve();
    image.onerror = () => reject(new Error("The browser could not decode this image."));
    image.src = sourceUrl;
  });
  const longest = Math.max(image.naturalWidth, image.naturalHeight);
  const scale = Math.min(1, 1600 / longest);
  const width = Math.round(image.naturalWidth * scale);
  const height = Math.round(image.naturalHeight * scale);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas is not available in this browser.");
  context.drawImage(image, 0, 0, width, height);
  URL.revokeObjectURL(sourceUrl);
  const blob = await new Promise<Blob>((resolve, reject) =>
    canvas.toBlob(value => (value ? resolve(value) : reject(new Error("Image compression failed."))), "image/jpeg", 0.86),
  );
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Image reading failed."));
    reader.readAsDataURL(blob);
  });
  const digest = await crypto.subtle.digest("SHA-256", await blob.arrayBuffer());
  const sha256 = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
  return { dataUrl, width, height, sha256 };
}

async function syntheticCaptureFile(view: CaptureView, blurred = false) {
  const width = 1280;
  const height = 900;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas is not available in this browser.");

  context.fillStyle = "#dedacf";
  context.fillRect(0, 0, width, height);
  const points: Record<CaptureView, [number, number][]> = {
    front: [[430, 70], [850, 70], [850, 830], [430, 830]],
    left_oblique: [[480, 125], [850, 70], [850, 830], [480, 775]],
    right_oblique: [[430, 70], [800, 125], [800, 775], [430, 830]],
    back: [[430, 70], [850, 70], [850, 830], [430, 830]],
  };
  const polygon = points[view];
  const drawPolygon = (shape: [number, number][], fill: string) => {
    context.beginPath();
    shape.forEach(([x, y], index) => index ? context.lineTo(x, y) : context.moveTo(x, y));
    context.closePath();
    context.fillStyle = fill;
    context.fill();
  };
  drawPolygon(polygon, "#161e1b");
  const centre = polygon.reduce((sum, [x, y]) => [sum[0] + x / 4, sum[1] + y / 4], [0, 0]);
  const inner = polygon.map(([x, y]) => [centre[0] + (x - centre[0]) * .91, centre[1] + (y - centre[1]) * .91] as [number, number]);
  drawPolygon(inner, "#4c524e");
  context.strokeStyle = "#737b76";
  context.lineWidth = 2;
  for (let index = 1; index < 8; index += 1) {
    const fraction = .12 + index * .095;
    const left = [inner[0][0] * (1 - fraction) + inner[3][0] * fraction, inner[0][1] * (1 - fraction) + inner[3][1] * fraction];
    const right = [inner[1][0] * (1 - fraction) + inner[2][0] * fraction, inner[1][1] * (1 - fraction) + inner[2][1] * fraction];
    context.beginPath();
    context.moveTo(left[0], left[1]);
    context.lineTo(right[0], right[1]);
    context.stroke();
  }
  context.fillStyle = "#e5e7df";
  context.beginPath();
  context.ellipse(730, 225, 46, 20, -.3, 0, Math.PI * 2);
  context.fill();
  if (view === "back") {
    context.fillStyle = "#101714";
    context.beginPath(); context.arc(492, 142, 17, 0, Math.PI * 2); context.fill();
    context.beginPath(); context.arc(532, 142, 17, 0, Math.PI * 2); context.fill();
  }
  context.fillStyle = "#1c4937";
  context.font = "500 15px DM Mono, monospace";
  context.fillText("SYNTHETIC TEST FIXTURE · NOT A REAL DEVICE", 28, 868);

  let output = canvas;
  if (blurred) {
    const tiny = document.createElement("canvas");
    tiny.width = 64;
    tiny.height = 45;
    tiny.getContext("2d")?.drawImage(canvas, 0, 0, tiny.width, tiny.height);
    output = document.createElement("canvas");
    output.width = width;
    output.height = height;
    const blurredContext = output.getContext("2d");
    if (!blurredContext) throw new Error("Canvas is not available in this browser.");
    blurredContext.imageSmoothingEnabled = true;
    blurredContext.drawImage(tiny, 0, 0, width, height);
  }
  const blob = await new Promise<Blob>((resolve, reject) => output.toBlob(value => value ? resolve(value) : reject(new Error("Synthetic fixture generation failed.")), "image/jpeg", .92));
  return new File([blob], `synthetic-${view}${blurred ? "-blurred" : ""}.jpg`, { type: "image/jpeg" });
}

function statusTone(status: ExplainableMetric["status"]) {
  return status === "pass" ? "metric-pass" : status === "warn" ? "metric-warn" : "metric-fail";
}

function MetricRow({ metric }: { metric: ExplainableMetric }) {
  return (
    <div className="metric-row">
      <span className={`metric-status ${statusTone(metric.status)}`} aria-label={metric.status} />
      <div className="metric-copy">
        <div className="metric-heading">
          <span>{metric.label}</span>
          <strong>{metric.value.toLocaleString(undefined, { maximumFractionDigits: 1 })} {metric.unit}</strong>
        </div>
        <div className="metric-track" aria-hidden="true">
          <span className={statusTone(metric.status)} style={{ width: `${Math.min(100, Math.max(7, metric.id === "focus" ? metric.value / 2 : metric.value))}%` }} />
        </div>
        <p>{metric.explanation} <span>Gate: {metric.threshold}</span></p>
      </div>
    </div>
  );
}

function StepRail({ session }: { session: InspectionSession }) {
  const current = session.status === "setup" ? 0 : session.status === "capturing" ? 1 : session.status === "ready_for_review" ? 2 : 3;
  const steps = [
    { label: "Consent & scope", icon: ShieldCheck },
    { label: "Guided capture", icon: Camera },
    { label: "Human review", icon: UserCheck },
    { label: "Audit package", icon: FileCheck2 },
  ];
  return (
    <nav className="step-rail" aria-label="Inspection progress">
      {steps.map((step, index) => {
        const Icon = step.icon;
        return (
          <div className={`step-item ${index === current ? "is-current" : ""} ${index < current ? "is-done" : ""}`} key={step.label}>
            <span className="step-index">{index < current ? <Check size={14} /> : <Icon size={15} />}</span>
            <div><small>0{index + 1}</small><strong>{step.label}</strong></div>
          </div>
        );
      })}
    </nav>
  );
}

function EvidenceStrip({ session }: { session: InspectionSession }) {
  return (
    <section className="evidence-strip" aria-label="Accepted evidence views">
      <div className="section-kicker"><Fingerprint size={14} /> Evidence set</div>
      <div className="evidence-grid">
        {(Object.keys(VIEW_LABELS) as CaptureView[]).map(view => {
          const capture = [...session.captures].reverse().find(item => item.view === view && item.accepted);
          return (
            <div className={`evidence-slot ${capture ? "has-evidence" : ""}`} key={view}>
              {capture ? <img src={capture.analysis.overlayDataUrl} alt={`${VIEW_LABELS[view]} evidence overlay`} /> : <ScanLine size={22} />}
              <span>{VIEW_LABELS[view]}</span>
              {capture && <small>{capture.sourceSha256.slice(0, 8)}…</small>}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function ProposalPanel({ proposal }: { proposal: CosmeticProposal }) {
  return (
    <section className="proposal-panel">
      <div>
        <div className="section-kicker"><Sparkles size={14} /> Prototype proposal</div>
        <div className="proposal-band">{proposal.band}</div>
      </div>
      <div className="proposal-detail">
        <span>{Math.round(proposal.confidence * 100)}% heuristic confidence</span>
        {proposal.rationale.map(item => <p key={item}>{item}</p>)}
        <small>{proposal.disclaimer}</small>
      </div>
    </section>
  );
}

export default function Home() {
  const [session, setSession] = useState<InspectionSession>(() => newSession());
  const [selected, setSelected] = useState<{ file: File; dataUrl: string; width: number; height: number; sha256: string } | null>(null);
  const [overrideBand, setOverrideBand] = useState<CosmeticProposal["band"]>("manual-review");
  const [reviewNote, setReviewNote] = useState("");
  const [demoRunning, setDemoRunning] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const health = trpc.vision.health.useQuery(undefined, { retry: 1 });
  const analyse = trpc.vision.analyse.useMutation();
  const latestCapture = session.captures.at(-1);
  const latestResult = latestCapture?.analysis;
  const currentProposal = [...session.captures].reverse().find(capture => capture.accepted)?.analysis.proposal;

  const acceptedViews = useMemo<AcceptedViewSummary[]>(() => session.acceptedViews, [session.acceptedViews]);

  const startInspection = () => {
    if (!session.deviceLabel.trim()) return toast.error("Add a non-identifying device label.");
    if (!session.consentAccepted) return toast.error("Confirm the privacy notice before continuing.");
    const timestamp = nowIso();
    setSession(current => ({
      ...current,
      status: "capturing",
      updatedAt: timestamp,
      auditEvents: [...current.auditEvents, { id: crypto.randomUUID(), timestamp, type: "capture_submitted", summary: "Inspection session started without server-side image persistence." }],
    }));
  };

  const chooseFile = async (file?: File) => {
    if (!file) return;
    try {
      const capture = await fileToCapture(file);
      setSelected({ file, ...capture });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to prepare this image.");
    }
  };

  const analyseSelected = async () => {
    if (!selected) return;
    const submittedAt = nowIso();
    try {
      const result = await analyse.mutateAsync({
        imageDataUrl: selected.dataUrl,
        requestedView: session.requestedView,
        acceptedViews,
        previousCapture: previousSummary(latestCapture),
      });
      const accepted = result.decision.status !== "recapture";
      const record: CaptureRecord = {
        id: result.captureId,
        view: session.requestedView,
        capturedAt: submittedAt,
        sourceName: selected.file.name,
        sourceSha256: selected.sha256,
        sourceWidth: selected.width,
        sourceHeight: selected.height,
        sourceDataUrl: selected.dataUrl,
        analysis: result,
        accepted,
      };
      setSession(current => {
        const nextAccepted = result.acceptedView
          ? [...current.acceptedViews.filter(item => item.view !== result.acceptedView?.view), result.acceptedView]
          : current.acceptedViews;
        const timestamp = nowIso();
        return {
          ...current,
          captures: [...current.captures, record],
          acceptedViews: nextAccepted,
          decisionHistory: [...current.decisionHistory, result.decision],
          auditEvents: [
            ...current.auditEvents,
            { id: crypto.randomUUID(), timestamp: submittedAt, type: "capture_submitted", summary: `${VIEW_LABELS[current.requestedView]} submitted; SHA-256 ${selected.sha256.slice(0, 12)}…` },
            { id: crypto.randomUUID(), timestamp, type: "analysis_completed", summary: `OpenCV ${result.opencvVersion} returned ${result.decision.reasonCode} in ${result.processingMs} ms.`, reasonCode: result.decision.reasonCode },
            ...(accepted ? [{ id: crypto.randomUUID(), timestamp, type: "view_accepted" as const, summary: `${VIEW_LABELS[current.requestedView]} admitted to the evidence set.`, reasonCode: result.decision.reasonCode }] : []),
          ],
          requestedView: result.decision.nextView ?? current.requestedView,
          status: result.decision.status === "complete" ? "ready_for_review" : "capturing",
          updatedAt: timestamp,
        };
      });
      setSelected(null);
      if (result.decision.status === "recapture") toast.error(result.decision.instruction);
      else toast.success(result.decision.instruction);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "OpenCV analysis failed.");
    }
  };

  const runSyntheticDemo = async () => {
    if (demoRunning) return;
    setDemoRunning(true);
    analyse.reset();
    const timestamp = nowIso();
    let localSession: InspectionSession = {
      ...newSession(),
      deviceLabel: "synthetic-reference-device",
      consentAccepted: true,
      status: "capturing",
      createdAt: timestamp,
      updatedAt: timestamp,
      auditEvents: [{ id: crypto.randomUUID(), timestamp, type: "capture_submitted", summary: "Declared synthetic reference run started; no real device or personal data is used." }],
    };
    setSession(localSession);
    setSelected(null);
    setReviewNote("");
    setOverrideBand("manual-review");

    try {
      for (let attempt = 0; attempt < 5; attempt += 1) {
        const requestedView = localSession.requestedView;
        const file = await syntheticCaptureFile(requestedView, attempt === 0);
        const prepared = await fileToCapture(file);
        const submittedAt = nowIso();
        const result = await analyse.mutateAsync({
          imageDataUrl: prepared.dataUrl,
          requestedView,
          acceptedViews: localSession.acceptedViews,
          previousCapture: previousSummary(localSession.captures.at(-1)),
        });
        const accepted = result.decision.status !== "recapture";
        const record: CaptureRecord = {
          id: result.captureId,
          view: requestedView,
          capturedAt: submittedAt,
          sourceName: file.name,
          sourceSha256: prepared.sha256,
          sourceWidth: prepared.width,
          sourceHeight: prepared.height,
          sourceDataUrl: prepared.dataUrl,
          analysis: result,
          accepted,
        };
        const nextAccepted = result.acceptedView
          ? [...localSession.acceptedViews.filter(item => item.view !== result.acceptedView?.view), result.acceptedView]
          : localSession.acceptedViews;
        const analysedAt = nowIso();
        localSession = {
          ...localSession,
          captures: [...localSession.captures, record],
          acceptedViews: nextAccepted,
          decisionHistory: [...localSession.decisionHistory, result.decision],
          auditEvents: [
            ...localSession.auditEvents,
            { id: crypto.randomUUID(), timestamp: submittedAt, type: "capture_submitted", summary: `${VIEW_LABELS[requestedView]} synthetic fixture submitted; SHA-256 ${prepared.sha256.slice(0, 12)}…` },
            { id: crypto.randomUUID(), timestamp: analysedAt, type: "analysis_completed", summary: `OpenCV ${result.opencvVersion} returned ${result.decision.reasonCode} in ${result.processingMs} ms.`, reasonCode: result.decision.reasonCode },
            ...(accepted ? [{ id: crypto.randomUUID(), timestamp: analysedAt, type: "view_accepted" as const, summary: `${VIEW_LABELS[requestedView]} admitted to the synthetic evidence set.`, reasonCode: result.decision.reasonCode }] : []),
          ],
          requestedView: result.decision.nextView ?? requestedView,
          status: result.decision.status === "complete" ? "ready_for_review" : "capturing",
          updatedAt: analysedAt,
        };
        setSession(localSession);
        await new Promise(resolve => window.setTimeout(resolve, 1600));
      }
      toast.success("Synthetic reference run completed with live OpenCV decisions.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Synthetic reference run failed.");
      setSession(current => ({ ...current, status: "setup", updatedAt: nowIso() }));
    } finally {
      setDemoRunning(false);
    }
  };

  const finishReview = (action: "confirmed" | "corrected" | "deferred") => {
    if (!currentProposal) return;
    const error = reviewValidationError(action, reviewNote);
    if (error) return toast.error(error);
    const reviewedAt = nowIso();
    setSession(current => applyReviewDecision({ session: current, action, proposedBand: currentProposal.band, overrideBand, note: reviewNote, reviewedAt, eventId: crypto.randomUUID() }));
  };

  const downloadAudit = () => {
    const safeSession = privacySafeAudit(session);
    const blob = new Blob([JSON.stringify(safeSession, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `reloop-audit-${session.id.slice(0, 8)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const downloadEvidencePackage = () => {
    const blob = new Blob([evidenceZip(session)], { type: "application/zip" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `reloop-evidence-${session.id.slice(0, 8)}.zip`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const reset = () => {
    setSession(newSession());
    setSelected(null);
    setReviewNote("");
    setOverrideBand("manual-review");
    analyse.reset();
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="ReLoop Inspector home">
          <span className="brand-mark"><Aperture size={19} /></span>
          <span><strong>ReLoop</strong><small>Inspector</small></span>
        </a>
        <div className="runtime-status">
          <span className={health.data?.ok ? "runtime-dot is-live" : "runtime-dot"} />
          {health.isLoading ? "Checking runtime" : health.data ? `OpenCV ${health.data.opencvVersion} live` : "Runtime unavailable"}
        </div>
        <Button variant="outline" className="reset-button" onClick={reset}><RotateCcw size={15} /> New inspection</Button>
      </header>

      <main id="top" className="page-frame">
        <section className="hero-grid">
          <div className="hero-copy">
            <Badge variant="outline" className="hero-badge">Agentic Vision · public prototype</Badge>
            <h1>Evidence should decide what happens next.</h1>
          </div>
          <div className="hero-aside">
            <p>ReLoop guides an operator through a four-view smartphone inspection. OpenCV measures image quality and pose, requests a specific correction when evidence is weak, then verifies the new capture before admitting it.</p>
            <div className="hero-principles"><span>Measure</span><ChevronRight size={14} /><span>Decide</span><ChevronRight size={14} /><span>Verify</span><ChevronRight size={14} /><span>Review</span></div>
          </div>
        </section>

        <div className="inspection-layout">
          <aside className="left-rail">
            <StepRail session={session} />
            <div className="boundary-note">
              <ShieldCheck size={18} />
              <strong>Responsible boundary</strong>
              <p>Cosmetic evidence only. No battery, water-resistance, authenticity or safety certification.</p>
            </div>
          </aside>

          <section className="workspace">
            {session.status === "setup" && (
              <div className="setup-panel panel-enter">
                <div className="workspace-heading">
                  <div><span className="eyebrow">Start with provenance</span><h2>Create an inspection session</h2></div>
                  <Fingerprint size={34} />
                </div>
                <p className="lead">Use a non-identifying device label. Images are analysed during the request and remain only in this browser session; the public MVP does not persist source files.</p>
                <div className="setup-fields">
                  <div className="field-group">
                    <Label htmlFor="device-label">Device label</Label>
                    <Input id="device-label" value={session.deviceLabel} onChange={event => setSession(current => ({ ...current, deviceLabel: event.target.value }))} placeholder="Example: demo-phone-01" maxLength={64} />
                    <small>Do not enter an IMEI, serial number, owner name or personal information.</small>
                  </div>
                  <div className="consent-line">
                    <Checkbox id="consent" checked={session.consentAccepted} onCheckedChange={checked => setSession(current => ({ ...current, consentAccepted: checked === true }))} />
                    <Label htmlFor="consent">I have the right to analyse these images and understand that this prototype provides cosmetic decision support only.</Label>
                  </div>
                </div>
                <div className="setup-actions">
                  <Button className="primary-action" onClick={startInspection}>Begin guided capture <ArrowRight size={17} /></Button>
                  <Button variant="outline" disabled={demoRunning} onClick={runSyntheticDemo}>
                    {demoRunning ? <><LoaderCircle className="spin" size={17} /> Running live analysis</> : <><Sparkles size={17} /> Run reproducible demo</>}
                  </Button>
                </div>
                <p className="demo-disclosure">The reference run generates clearly labelled synthetic images in your browser, then sends them through the same OpenCV 5 endpoint as uploaded captures.</p>
              </div>
            )}

            {session.status === "capturing" && (
              <div className="capture-stage panel-enter">
                <div className="workspace-heading compact">
                  <div><span className="eyebrow">Requested view</span><h2>{VIEW_LABELS[session.requestedView]}</h2></div>
                  <span className="view-counter">{session.acceptedViews.length} / 4 accepted</span>
                </div>
                <div className="instruction-band">
                  <span className="instruction-number">{String(session.decisionHistory.length + 1).padStart(2, "0")}</span>
                  <div><strong>{latestResult?.decision.status === "recapture" ? latestResult.decision.instruction : VIEW_NOTES[session.requestedView]}</strong><p>The next action is selected from measured focus, exposure, glare, coverage and pose—not from a scripted slideshow.</p></div>
                </div>

                <div className="capture-grid">
                  <div className={`capture-canvas ${selected ? "has-image" : ""}`}>
                    {selected ? (
                      <img src={selected.dataUrl} alt="Selected smartphone capture" />
                    ) : (
                      <div className="phone-guide">
                        <div className={`phone-outline view-${session.requestedView}`}><span /></div>
                        <p>Align the full device inside the guide</p>
                      </div>
                    )}
                    <div className="capture-corners" aria-hidden="true"><i /><i /><i /><i /></div>
                  </div>
                  <div className="capture-controls">
                    <input ref={fileInput} type="file" accept="image/jpeg,image/png,image/webp" capture="environment" hidden onChange={event => chooseFile(event.target.files?.[0])} />
                    <Button variant="outline" className="upload-button" onClick={() => fileInput.current?.click()}><ImagePlus size={18} /> {selected ? "Replace image" : "Choose image or camera"}</Button>
                    <div className="privacy-chip"><ShieldCheck size={14} /> Request-scoped analysis</div>
                    {selected && <div className="file-facts"><span>{selected.file.name}</span><small>{selected.width} × {selected.height} · SHA-256 {selected.sha256.slice(0, 10)}…</small></div>}
                    <Button className="primary-action" disabled={!selected || analyse.isPending} onClick={analyseSelected}>
                      {analyse.isPending ? <><LoaderCircle className="spin" size={17} /> Analysing with OpenCV</> : <><ScanLine size={17} /> Analyse this view</>}
                    </Button>
                    <small className="control-note">Accepted formats: JPEG, PNG, WebP. The browser compresses the image before analysis.</small>
                  </div>
                </div>

                {latestResult && (
                  <div className={`decision-panel ${latestResult.decision.status}`}>
                    <div className="decision-title">
                      <span>{latestResult.decision.status === "recapture" ? <CircleAlert /> : <CheckCircle2 />}</span>
                      <div><small>{latestResult.decision.reasonCode}</small><h3>{latestResult.decision.instruction}</h3><p>{latestResult.decision.explanation}</p></div>
                      <Badge variant="outline">{latestResult.processingMs} ms</Badge>
                    </div>
                    {latestResult.decision.verification.attempted && (
                      <div className={`verification-row ${latestResult.decision.verification.passed ? "verified" : "not-verified"}`}>
                        {latestResult.decision.verification.passed ? <Check size={16} /> : <X size={16} />}
                        <span>{latestResult.decision.verification.explanation}</span>
                        <small>{latestResult.decision.verification.previousValue} → {latestResult.decision.verification.currentValue}</small>
                      </div>
                    )}
                    <div className="analysis-grid">
                      <figure className="overlay-frame"><img src={latestResult.overlayDataUrl} alt="OpenCV explainability overlay" /><figcaption>Green: device boundary · Yellow: glare · Blue: candidate surface marks</figcaption></figure>
                      <div className="metric-list">{latestResult.metrics.map(metric => <MetricRow metric={metric} key={metric.id} />)}</div>
                    </div>
                  </div>
                )}
                <EvidenceStrip session={session} />
              </div>
            )}

            {session.status === "ready_for_review" && currentProposal && (
              <div className="review-stage panel-enter">
                <div className="workspace-heading">
                  <div><span className="eyebrow">Human-in-the-loop</span><h2>Review the evidence, not just the grade</h2></div>
                  <UserCheck size={34} />
                </div>
                <ProposalPanel proposal={currentProposal} />
                <EvidenceStrip session={session} />
                <div className="review-grid">
                  <div className="review-copy"><h3>Make an accountable decision</h3><p>Confirmation accepts the prototype proposal. Correction requires a new band and rationale. Deferral records uncertainty without forcing a grade.</p></div>
                  <div className="review-form">
                    <Label>Correction or deferral band</Label>
                    <Select value={overrideBand} onValueChange={value => setOverrideBand(value as CosmeticProposal["band"])}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A-candidate">A-candidate</SelectItem>
                        <SelectItem value="B-candidate">B-candidate</SelectItem>
                        <SelectItem value="C-candidate">C-candidate</SelectItem>
                        <SelectItem value="manual-review">Manual review</SelectItem>
                      </SelectContent>
                    </Select>
                    <Label htmlFor="review-note">Reviewer rationale</Label>
                    <Textarea id="review-note" value={reviewNote} onChange={event => setReviewNote(event.target.value)} placeholder="Explain the correction or why more evidence is needed…" />
                    <div className="review-actions">
                      <Button className="primary-action" onClick={() => finishReview("confirmed")}><Check size={16} /> Confirm proposal</Button>
                      <Button variant="outline" onClick={() => finishReview("corrected")}><RefreshCw size={16} /> Correct</Button>
                      <Button variant="ghost" onClick={() => finishReview("deferred")}><CircleAlert size={16} /> Defer</Button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {(session.status === "completed" || session.status === "deferred") && session.review && (
              <div className="completion-stage panel-enter">
                <div className="completion-icon">{session.status === "completed" ? <CheckCircle2 size={38} /> : <CircleAlert size={38} />}</div>
                <span className="eyebrow">Audit-ready outcome</span>
                <h2>{session.review.finalBand}</h2>
                <p>The human reviewer <strong>{session.review.action}</strong> the prototype proposal. The audit package records every capture, OpenCV decision, threshold, verification step and provenance hash.</p>
                {session.review.note && <blockquote>{session.review.note}</blockquote>}
                <div className="completion-actions"><Button className="primary-action" onClick={downloadEvidencePackage}><Download size={17} /> Download evidence ZIP</Button><Button variant="outline" onClick={downloadAudit}>Metadata JSON</Button><Button variant="outline" onClick={reset}><RotateCcw size={16} /> Start another</Button></div>
                <EvidenceStrip session={session} />
              </div>
            )}
          </section>

          <aside className="right-rail">
            <div className="runtime-card">
              <div className="section-kicker"><CircleGauge size={14} /> Runtime evidence</div>
              <dl><div><dt>Engine</dt><dd>{health.data ? `OpenCV ${health.data.opencvVersion}` : "Checking…"}</dd></div><div><dt>Accepted views</dt><dd>{session.acceptedViews.length} / 4</dd></div><div><dt>Total attempts</dt><dd>{session.captures.length}</dd></div><div><dt>Storage</dt><dd>Browser session</dd></div></dl>
            </div>
            <div className="audit-timeline">
              <div className="section-kicker"><Eye size={14} /> Decision trace</div>
              {session.auditEvents.length ? session.auditEvents.slice(-6).reverse().map(event => <div className="audit-event" key={event.id}><span /><div><small>{new Date(event.timestamp).toLocaleTimeString()}</small><p>{event.summary}</p></div></div>) : <p className="empty-trace">The trace begins when the inspection starts.</p>}
            </div>
          </aside>
        </div>
      </main>

      <footer><span>Team MERAVIGLIA · OpenCV AI Competition 2026</span><span>Prototype decision support · not a safety certificate</span></footer>
    </div>
  );
}
