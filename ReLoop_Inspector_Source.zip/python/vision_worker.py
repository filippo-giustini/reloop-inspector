#!/usr/bin/env python3
"""Deterministic OpenCV worker for the ReLoop Inspector public demo."""

from __future__ import annotations

import argparse
import base64
import json
import math
import sys
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np


FOCUS_MIN = 80.0
LUMINANCE_MIN = 45.0
LUMINANCE_MAX = 215.0
BLACK_CLIP_MAX = 0.15
WHITE_CLIP_MAX = 0.10
GLARE_MAX = 0.08
COVERAGE_MIN = 0.22
COVERAGE_MAX = 0.90
POSE_MIN = 0.55

VIEW_SEQUENCE = ["front", "left_oblique", "right_oblique", "back"]


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def distance(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b))


def order_points(points: np.ndarray) -> np.ndarray:
    pts = points.astype(np.float32)
    sums = pts.sum(axis=1)
    diffs = np.diff(pts, axis=1).reshape(-1)
    return np.array(
        [pts[np.argmin(sums)], pts[np.argmin(diffs)], pts[np.argmax(sums)], pts[np.argmax(diffs)]],
        dtype=np.float32,
    )


def detect_device(image: np.ndarray) -> dict[str, Any]:
    height, width = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 45, 130)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 7))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel, iterations=2)
    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    best: dict[str, Any] | None = None
    image_area = float(width * height)
    for contour in contours:
        area = float(cv2.contourArea(contour))
        area_ratio = area / image_area
        if area_ratio < 0.10 or area_ratio > 0.94:
            continue
        rect = cv2.minAreaRect(contour)
        rect_w, rect_h = rect[1]
        if rect_w < 2 or rect_h < 2:
            continue
        long_side = max(rect_w, rect_h)
        short_side = min(rect_w, rect_h)
        aspect = long_side / short_side
        rect_area = rect_w * rect_h
        rectangularity = area / rect_area if rect_area else 0.0
        if not (1.25 <= aspect <= 2.8 and rectangularity >= 0.42):
            continue
        score = area_ratio * rectangularity
        perimeter = cv2.arcLength(contour, True)
        approximation = cv2.approxPolyDP(contour, 0.025 * perimeter, True)
        if len(approximation) == 4 and cv2.isContourConvex(approximation):
            box = order_points(approximation.reshape(4, 2))
        else:
            box = order_points(cv2.boxPoints(rect))
        if best is None or score > best["score"]:
            best = {
                "score": score,
                "contour": contour,
                "box": box,
                "coverage": area / image_area,
                "rectangularity": rectangularity,
                "aspect": aspect,
            }

    if best is None:
        return {
            "detected": False,
            "coverage": 0.0,
            "box": None,
            "mask": np.full(gray.shape, 255, dtype=np.uint8),
            "pose_score": 0.0,
            "signed_skew": 0.0,
            "perspective_asymmetry": 1.0,
        }

    box = best["box"]
    tl, tr, br, bl = box
    left = distance(tl, bl)
    right = distance(tr, br)
    top = distance(tl, tr)
    bottom = distance(bl, br)
    vertical_skew = (right - left) / max(right, left, 1.0)
    horizontal_skew = (bottom - top) / max(bottom, top, 1.0)
    asymmetry = (abs(vertical_skew) + abs(horizontal_skew)) / 2.0
    pose_score = clamp(1.0 - asymmetry / 0.42)
    mask = np.zeros(gray.shape, dtype=np.uint8)
    cv2.fillConvexPoly(mask, np.int32(box), 255)
    return {
        "detected": True,
        "score": float(best["score"]),
        "coverage": float(best["coverage"]),
        "box": box,
        "mask": mask,
        "pose_score": pose_score,
        "signed_skew": float(vertical_skew),
        "perspective_asymmetry": float(asymmetry),
    }


def masked_values(channel: np.ndarray, mask: np.ndarray) -> np.ndarray:
    values = channel[mask > 0]
    return values if values.size else channel.reshape(-1)


def metric(
    metric_id: str,
    label: str,
    value: float,
    unit: str,
    threshold: str,
    status: str,
    explanation: str,
) -> dict[str, Any]:
    return {
        "id": metric_id,
        "label": label,
        "value": round(float(value), 3),
        "unit": unit,
        "threshold": threshold,
        "status": status,
        "explanation": explanation,
    }


def analyse_quality(image: np.ndarray, device: dict[str, Any], requested_view: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    mask = device["mask"]
    pixels = masked_values(gray, mask)

    focus = float(cv2.Laplacian(gray, cv2.CV_64F)[mask > 0].var()) if np.any(mask > 0) else 0.0
    luminance = float(np.mean(pixels))
    black_clipping = float(np.mean(pixels <= 8))
    white_clipping = float(np.mean(pixels >= 247))

    glare_mask = cv2.inRange(hsv, np.array([0, 0, 238]), np.array([179, 72, 255]))
    glare_mask = cv2.bitwise_and(glare_mask, mask)
    glare_mask = cv2.morphologyEx(glare_mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    glare_pixels = int(np.count_nonzero(glare_mask))
    device_pixels = max(int(np.count_nonzero(mask)), 1)
    glare = glare_pixels / device_pixels

    coverage = float(device["coverage"])
    signed_skew = float(device["signed_skew"])
    if requested_view in {"front", "back"}:
        pose = float(device["pose_score"])
        pose_pass = pose >= POSE_MIN
        pose_rule = f"≥ {POSE_MIN:.2f} frontal score"
        pose_explanation = "Frontal views should keep opposite device edges visually balanced."
    elif requested_view == "left_oblique":
        pose = clamp((signed_skew + 0.04) / 0.30)
        pose_pass = signed_skew >= 0.04
        pose_rule = "left edge recedes; signed skew ≥ 0.04"
        pose_explanation = "The left edge should recede enough to reveal angle-dependent surface evidence."
    else:
        pose = clamp((-signed_skew + 0.04) / 0.30)
        pose_pass = signed_skew <= -0.04
        pose_rule = "right edge recedes; signed skew ≤ −0.04"
        pose_explanation = "The right edge should recede enough to reveal angle-dependent surface evidence."

    metrics = [
        metric("focus", "Focus", focus, "Laplacian variance", f"≥ {FOCUS_MIN:.0f}", "pass" if focus >= FOCUS_MIN else "fail", "Higher edge variance indicates a sharper capture."),
        metric("luminance", "Exposure", luminance, "mean luminance", f"{LUMINANCE_MIN:.0f}–{LUMINANCE_MAX:.0f}", "pass" if LUMINANCE_MIN <= luminance <= LUMINANCE_MAX else "fail", "Mean luminance should preserve both dark and bright surface detail."),
        metric("blackClipping", "Black clipping", black_clipping * 100, "% pixels", f"≤ {BLACK_CLIP_MAX * 100:.0f}%", "pass" if black_clipping <= BLACK_CLIP_MAX else "fail", "Clipped shadows can hide dark scratches and edge damage."),
        metric("whiteClipping", "White clipping", white_clipping * 100, "% pixels", f"≤ {WHITE_CLIP_MAX * 100:.0f}%", "pass" if white_clipping <= WHITE_CLIP_MAX else "fail", "Clipped highlights can erase fine surface detail."),
        metric("glare", "Glare", glare * 100, "% device area", f"≤ {GLARE_MAX * 100:.0f}%", "pass" if glare <= GLARE_MAX else "fail", "Bright low-saturation regions are treated as possible specular glare."),
        metric("coverage", "Device coverage", coverage * 100, "% frame", f"{COVERAGE_MIN * 100:.0f}–{COVERAGE_MAX * 100:.0f}%", "pass" if device["detected"] and COVERAGE_MIN <= coverage <= COVERAGE_MAX else "fail", "The full device should be visible while occupying enough of the frame."),
        metric("pose", "Requested pose", pose * 100, "% pose score", pose_rule, "pass" if device["detected"] and pose_pass else "fail", pose_explanation),
    ]
    return metrics, {"glare_mask": glare_mask, "pose_pass": pose_pass, "pose": pose}


def find_candidate_marks(image: np.ndarray, device: dict[str, Any]) -> tuple[list[tuple[int, int, int, int]], float]:
    if not device["detected"]:
        return [], 0.0
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    interior = cv2.erode(device["mask"], np.ones((17, 17), np.uint8), iterations=1)
    local = cv2.createCLAHE(clipLimit=1.8, tileGridSize=(8, 8)).apply(gray)
    edges = cv2.Canny(local, 70, 165)
    edges = cv2.bitwise_and(edges, interior)
    diagonal = math.hypot(image.shape[1], image.shape[0])
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=22, minLineLength=max(12, int(diagonal * 0.025)), maxLineGap=5)
    candidates: list[tuple[int, int, int, int]] = []
    if lines is not None:
        for line in np.asarray(lines).reshape(-1, 4)[:80]:
            x1, y1, x2, y2 = [int(v) for v in line]
            length = math.hypot(x2 - x1, y2 - y1)
            if length <= diagonal * 0.28:
                candidates.append((x1, y1, x2, y2))
    density = min(len(candidates) / 40.0, 1.0)
    return candidates, density


def value_of(metrics: list[dict[str, Any]], metric_id: str) -> float:
    return float(next(item["value"] for item in metrics if item["id"] == metric_id))


def fail_metric(metrics: list[dict[str, Any]], metric_id: str) -> bool:
    return next(item["status"] for item in metrics if item["id"] == metric_id) == "fail"


def verify_correction(previous: dict[str, Any] | None, metrics: list[dict[str, Any]]) -> dict[str, Any]:
    if not previous:
        return {"attempted": False, "passed": True, "explanation": "No prior corrective request exists for this capture."}
    reason = previous.get("reasonCode")
    mapping = {
        "FOCUS_TOO_LOW": ("focus", "increase by at least 15% and pass the focus threshold"),
        "UNDEREXPOSED": ("luminance", "move into the accepted exposure range"),
        "OVEREXPOSED": ("luminance", "move into the accepted exposure range"),
        "EXCESSIVE_GLARE": ("glare", "decrease by at least 20% and pass the glare threshold"),
        "DEVICE_TOO_SMALL": ("coverage", "increase by at least 5 percentage points"),
        "DEVICE_NOT_FOUND": ("coverage", "make the device detectable with sufficient coverage"),
        "POSE_NOT_VERIFIED": ("pose", "pass the requested pose rule"),
        "CORRECTIVE_ACTION_NOT_VERIFIED": ("pose", "pass the requested pose rule"),
    }
    if reason not in mapping:
        return {"attempted": False, "passed": True, "explanation": "The prior capture did not request a measurable correction."}
    metric_id, requirement = mapping[reason]
    current = value_of(metrics, metric_id)
    previous_value = float(previous.get(metric_id, 0.0))
    current_pass = not fail_metric(metrics, metric_id)
    if metric_id == "focus":
        improved = current >= previous_value * 1.15
    elif metric_id == "glare":
        improved = current <= previous_value * 0.80
    elif metric_id == "coverage":
        improved = current >= previous_value + 5.0
    elif metric_id == "pose":
        improved = current >= previous_value + 8.0
    else:
        improved = current_pass
    passed = bool(current_pass and improved)
    return {
        "attempted": True,
        "passed": passed,
        "metricId": metric_id,
        "previousValue": round(previous_value, 3),
        "currentValue": round(current, 3),
        "requiredChange": requirement,
        "explanation": "The corrective capture passed the requested measurement." if passed else "The new capture did not yet satisfy the requested measurable change.",
    }


def choose_decision(
    requested_view: str,
    metrics: list[dict[str, Any]],
    device: dict[str, Any],
    glare_mask: np.ndarray,
    accepted_views: list[dict[str, Any]],
    verification: dict[str, Any],
) -> dict[str, Any]:
    height, width = glare_mask.shape
    instructions = {
        "IMAGE_TOO_SMALL": "Move closer or use a higher-resolution image, then capture again.",
        "FOCUS_TOO_LOW": "Hold the camera steady, tap the phone surface to focus, and capture again.",
        "UNDEREXPOSED": "Add soft ambient light without using direct flash, then capture again.",
        "OVEREXPOSED": "Reduce direct light or move away from the light source, then capture again.",
        "EXCESSIVE_GLARE": "Tilt the phone away from the brightest reflection and capture again.",
        "DEVICE_NOT_FOUND": "Place the whole phone on a contrasting background and align it inside the guide.",
        "DEVICE_TOO_SMALL": "Move closer while keeping all four device corners visible.",
        "POSE_NOT_VERIFIED": f"Adjust the phone to match the {requested_view.replace('_', ' ')} guide, then capture again.",
        "CORRECTIVE_ACTION_NOT_VERIFIED": "Repeat the requested correction more clearly; the measurable change was not verified.",
    }

    if not verification["passed"]:
        reason = "CORRECTIVE_ACTION_NOT_VERIFIED"
    elif fail_metric(metrics, "focus"):
        reason = "FOCUS_TOO_LOW"
    elif value_of(metrics, "luminance") < LUMINANCE_MIN:
        reason = "UNDEREXPOSED"
    elif value_of(metrics, "luminance") > LUMINANCE_MAX or fail_metric(metrics, "whiteClipping"):
        reason = "OVEREXPOSED"
    elif fail_metric(metrics, "glare"):
        reason = "EXCESSIVE_GLARE"
        moments = cv2.moments(glare_mask)
        if moments["m00"] > 0:
            cx = moments["m10"] / moments["m00"]
            direction = "right" if cx < width / 2 else "left"
            instructions[reason] = f"Tilt the phone slightly to the {direction} to move the brightest reflection off the surface."
    elif not device["detected"]:
        reason = "DEVICE_NOT_FOUND"
    elif fail_metric(metrics, "coverage"):
        reason = "DEVICE_TOO_SMALL"
    elif fail_metric(metrics, "pose"):
        reason = "POSE_NOT_VERIFIED"
    else:
        reason = None

    if reason:
        return {
            "status": "recapture",
            "reasonCode": reason,
            "requestedView": requested_view,
            "nextView": requested_view,
            "instruction": instructions[reason],
            "explanation": f"OpenCV measurements rejected this frame with reason code {reason}.",
            "verification": verification,
        }

    accepted_names = {item.get("view") for item in accepted_views}
    accepted_names.add(requested_view)
    missing = [view for view in VIEW_SEQUENCE if view not in accepted_names]
    if not missing:
        return {
            "status": "complete",
            "reasonCode": "EVIDENCE_SET_COMPLETE",
            "requestedView": requested_view,
            "nextView": None,
            "instruction": "Review the complete evidence set and make a human decision.",
            "explanation": "All four requested views passed their measurable quality and pose gates.",
            "verification": verification,
        }
    next_view = missing[0]
    return {
        "status": "accepted",
        "reasonCode": "VIEW_ACCEPTED",
        "requestedView": requested_view,
        "nextView": next_view,
        "instruction": f"View accepted. Capture the {next_view.replace('_', ' ')} view next.",
        "explanation": "This frame passed the active OpenCV quality and pose gates.",
        "verification": verification,
    }


def create_overlay(
    image: np.ndarray,
    device: dict[str, Any],
    glare_mask: np.ndarray,
    candidates: list[tuple[int, int, int, int]],
    decision: dict[str, Any],
) -> str:
    overlay = image.copy()
    if device["detected"]:
        cv2.polylines(overlay, [np.int32(device["box"])], True, (35, 122, 78), 4, cv2.LINE_AA)
    contours, _ = cv2.findContours(glare_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        if cv2.contourArea(contour) > 60:
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(overlay, (x, y), (x + w, y + h), (235, 179, 28), 3)
    for x1, y1, x2, y2 in candidates[:32]:
        cv2.line(overlay, (x1, y1), (x2, y2), (35, 185, 238), 2, cv2.LINE_AA)

    status_color = (38, 145, 76) if decision["status"] != "recapture" else (36, 68, 214)
    title = f'{decision["status"].upper()} · {decision["reasonCode"]}'
    cv2.rectangle(overlay, (0, 0), (overlay.shape[1], 58), (247, 244, 235), -1)
    cv2.putText(overlay, title, (22, 39), cv2.FONT_HERSHEY_SIMPLEX, 0.78, status_color, 2, cv2.LINE_AA)
    ok, encoded = cv2.imencode(".jpg", overlay, [int(cv2.IMWRITE_JPEG_QUALITY), 84])
    if not ok:
        raise RuntimeError("Unable to encode evidence overlay")
    return "data:image/jpeg;base64," + base64.b64encode(encoded.tobytes()).decode("ascii")


def proposal(candidate_density: float, accepted_views: list[dict[str, Any]], current_marks: int) -> dict[str, Any]:
    all_marks = [int(item.get("candidateMarks", 0)) for item in accepted_views] + [current_marks]
    mean_marks = float(np.mean(all_marks)) if all_marks else 0.0
    if mean_marks >= 26 or candidate_density >= 0.72:
        band = "C-candidate"
    elif mean_marks >= 10 or candidate_density >= 0.30:
        band = "B-candidate"
    else:
        band = "A-candidate"
    return {
        "band": band,
        "confidence": round(min(0.68, 0.34 + 0.07 * len(all_marks)), 2),
        "rationale": [
            f"{len(all_marks)} accepted view(s) currently contribute to the proposal.",
            f"Mean candidate surface-mark count: {mean_marks:.1f}.",
            "Quality and pose gates passed before evidence was admitted.",
        ],
        "disclaimer": "Prototype heuristic only. Candidate marks are not validated defects and the proposed band requires human review.",
    }


def analyse(payload: dict[str, Any]) -> dict[str, Any]:
    start = time.perf_counter()
    image_path = Path(payload["imagePath"])
    image = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("OpenCV could not decode the submitted image")
    original_height, original_width = image.shape[:2]
    if original_width < 320 or original_height < 240:
        raise ValueError("Image must be at least 320×240 pixels")
    max_side = max(original_width, original_height)
    if max_side > 1800:
        scale = 1800.0 / max_side
        image = cv2.resize(image, (int(original_width * scale), int(original_height * scale)), interpolation=cv2.INTER_AREA)

    requested_view = payload.get("requestedView", "front")
    accepted_views = payload.get("acceptedViews", [])
    previous = payload.get("previousCapture")
    device = detect_device(image)
    metrics, artifacts = analyse_quality(image, device, requested_view)
    candidates, candidate_density = find_candidate_marks(image, device)
    verification = verify_correction(previous, metrics)
    decision = choose_decision(requested_view, metrics, device, artifacts["glare_mask"], accepted_views, verification)
    current_marks = len(candidates)
    result: dict[str, Any] = {
        "captureId": payload["captureId"],
        "opencvVersion": cv2.__version__,
        "processingMs": 0,
        "image": {"width": int(image.shape[1]), "height": int(image.shape[0])},
        "metrics": metrics,
        "evidence": [],
        "decision": decision,
        "proposal": proposal(candidate_density, accepted_views, current_marks),
        "overlayDataUrl": "",
    }
    if device["detected"]:
        result["evidence"].append({"type": "device_boundary", "label": "Detected device boundary", "confidence": round(clamp(device["score"] * 2.2), 2)})
        result["evidence"].append({"type": "pose_axis", "label": f"Requested pose score: {value_of(metrics, 'pose'):.1f}%", "confidence": round(value_of(metrics, "pose") / 100.0, 2)})
    if value_of(metrics, "glare") > 0.5:
        result["evidence"].append({"type": "glare_region", "label": "Bright low-saturation regions", "confidence": round(clamp(value_of(metrics, "glare") / 16.0), 2)})
    if current_marks:
        result["evidence"].append({"type": "candidate_surface_mark", "label": f"{current_marks} candidate line segments", "confidence": round(clamp(candidate_density), 2)})
    if decision["status"] != "recapture":
        result["acceptedView"] = {
            "view": requested_view,
            "captureId": payload["captureId"],
            "focus": value_of(metrics, "focus"),
            "glare": value_of(metrics, "glare"),
            "coverage": value_of(metrics, "coverage"),
            "candidateMarks": current_marks,
        }
    result["overlayDataUrl"] = create_overlay(image, device, artifacts["glare_mask"], candidates, decision)
    result["processingMs"] = int((time.perf_counter() - start) * 1000)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--health", action="store_true")
    args = parser.parse_args()
    if args.health:
        print(json.dumps({"ok": True, "opencvVersion": cv2.__version__, "numpyVersion": np.__version__}))
        return
    payload = json.load(sys.stdin)
    print(json.dumps(analyse(payload), separators=(",", ":")))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"error": str(exc), "type": exc.__class__.__name__}), file=sys.stderr)
        sys.exit(1)
