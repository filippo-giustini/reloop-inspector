#!/usr/bin/env python3
"""Create deterministic synthetic captures for automated runtime tests only."""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np


def build_capture(view: str = "front") -> np.ndarray:
    canvas = np.full((900, 1280, 3), (224, 220, 207), dtype=np.uint8)
    outer = {
        "front": np.array([[430, 70], [850, 70], [850, 830], [430, 830]], np.int32),
        "left_oblique": np.array([[480, 125], [850, 70], [850, 830], [480, 775]], np.int32),
        "right_oblique": np.array([[430, 70], [800, 125], [800, 775], [430, 830]], np.int32),
        "back": np.array([[430, 70], [850, 70], [850, 830], [430, 830]], np.int32),
    }[view]
    cv2.fillConvexPoly(canvas, outer, (22, 30, 27))
    inner = outer.astype(np.float32)
    center = inner.mean(axis=0)
    inner = np.int32(center + (inner - center) * 0.91)
    cv2.fillConvexPoly(canvas, inner, (76, 82, 78))
    if view == "back":
        cv2.circle(canvas, tuple(inner[0] + np.array([48, 52])), 17, (18, 23, 20), -1)
        cv2.circle(canvas, tuple(inner[0] + np.array([88, 52])), 17, (18, 23, 20), -1)
    else:
        cv2.circle(canvas, (640, 112), 8, (20, 24, 22), -1)
    for fraction in np.linspace(0.16, 0.82, 8):
        left = inner[0] * (1 - fraction) + inner[3] * fraction
        right = inner[1] * (1 - fraction) + inner[2] * fraction
        cv2.line(canvas, tuple(np.int32(left)), tuple(np.int32(right)), (90, 94, 91), 2)
    cv2.line(canvas, tuple(np.int32(inner[0] * .70 + inner[3] * .30)), tuple(np.int32(inner[1] * .60 + inner[2] * .40)), (128, 134, 130), 2, cv2.LINE_AA)
    cv2.ellipse(canvas, tuple(np.int32(center + np.array([90, -220]))), (38, 18), -18, 0, 360, (226, 228, 222), -1)
    cv2.putText(canvas, "SYNTHETIC TEST FIXTURE", (28, 868), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (52, 70, 61), 2, cv2.LINE_AA)
    return canvas


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output_dir")
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    sharp = build_capture("front")
    blurred = cv2.GaussianBlur(sharp, (51, 51), 0)
    cv2.imwrite(str(output / "phone_good.jpg"), sharp, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
    cv2.imwrite(str(output / "phone_blurred.jpg"), blurred, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
    for view in ("left_oblique", "right_oblique", "back"):
        cv2.imwrite(str(output / f"phone_{view}.jpg"), build_capture(view), [int(cv2.IMWRITE_JPEG_QUALITY), 92])


if __name__ == "__main__":
    main()
